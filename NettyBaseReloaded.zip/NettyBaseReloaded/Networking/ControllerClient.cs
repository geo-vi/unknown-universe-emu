﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Controller.netty;

namespace NettyBaseReloaded.Networking
{
    class ControllerClient
    {
        private XSocket XSocket;

        public ControllerClient(XSocket gameSocket)
        {
            XSocket = gameSocket;
            XSocket.OnReceive += XSocketOnOnReceive;
            XSocket.ConnectionClosedEvent += XSocketOnConnectionClosedEvent;
            XSocket.Read();
        }

        private void XSocketOnConnectionClosedEvent(object sender, EventArgs eventArgs)
        {
            Controller.Controller.Clients.Remove(this);
        }

        private void XSocketOnOnReceive(object sender, EventArgs e)
        {
            var bytes = (ByteArrayArgs)e;
            CommandHandler.Handle(bytes.ByteArray, this);
        }

        public void Send(byte[] bytes)
        {
            try
            {
                XSocket.Write(bytes);
            }
            catch (Exception)
            {
                
            }
        }
    }
}
