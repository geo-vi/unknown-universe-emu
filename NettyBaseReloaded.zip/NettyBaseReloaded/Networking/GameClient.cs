﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game;
using NettyBaseReloaded.Game.netty;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Main;
using NettyBaseReloaded.Main.global_managers;

namespace NettyBaseReloaded.Networking
{
    class GameClient
    {
        private XSocket XSocket;
        public int UserId { get; set; }

        public GameClient(XSocket gameSocket)
        {
            XSocket = gameSocket;
            XSocket.OnReceive += XSocketOnOnReceive;
            XSocket.ConnectionClosedEvent += XSocketOnConnectionClosedEvent;
            XSocket.Read();
        }

        private void XSocketOnConnectionClosedEvent(object sender, EventArgs eventArgs)
        {
           
            var gameSess = World.StorageManager.GetGameSession(UserId);
            gameSess?.Disconnect();
        }

        private void XSocketOnOnReceive(object sender, EventArgs eventArgs)
        {
            var bytes = (ByteArrayArgs)eventArgs;
            var packet = Encoding.UTF8.GetString(bytes.ByteArray);

            const string policyPacket = "<?xml version=\"1.0\"?>\r\n" +
                                        "<!DOCTYPE cross-domain-policy SYSTEM \"/xml/dtds/cross-domain-policy.dtd\">\r\n" +
                                        "<cross-domain-policy>\r\n" +
                                        "<allow-access-from domain=\"*\" to-ports=\"*\" />\r\n" +
                                        "</cross-domain-policy>";

            if (packet.StartsWith("<policy-file-request/>"))
                XSocket.Write(policyPacket);
            else
                CommandHandler.Handle(bytes.ByteArray, this);
        }

        public void Send(byte[] bytes)
        {
            try
            {
                //if (World.StorageManager.GameSessions[UserId].Player.Controller != null)
                //    World.StorageManager.GameSessions[UserId].LastActiveTime = DateTime.Now;

                XSocket.Write(bytes);
            }
            catch (Exception)
            {
                Debug.WriteLine("Connected?");
            }
        }
        public void Send(string packet)
        {
            XSocket.Write(packet);
        }

        public static void SendRangePacket(Character character, byte[] command, bool sendCharacter = false)
        {
            if (character == null) return;
            try
            {
                foreach (var entry in character.Spacemap.Entities)
                {
                    var entity = entry.Value;

                    if (character.InRange(entity) && entity is Player)
                    {
                        World.StorageManager.GameSessions[entity.Id].Client.Send(command);
                    }
                }

                if (sendCharacter && character is Player)
                    World.StorageManager.GameSessions[character.Id].Client.Send(command);
            }
            catch (Exception e)
            {
                Out.WriteLine("Something went wrong sending a range packet.", "ERROR", ConsoleColor.Red);
                Debug.WriteLine(e.Message, "Debug Error");
            }
        }

        public static void SendPacketSelected(Character character, byte[] command)
        {
            try
            {
                foreach (var entry in character.Spacemap.Entities)
                {
                    var entity = entry.Value;

                    if (entity is Player && entity.Selected != null)
                    {
                        if (entity.Selected.Id == character.Id)
                            World.StorageManager.GameSessions[entity.Id].Client.Send(command);
                    }
                }
            }
            catch (Exception e)
            {
                Out.WriteLine("Something went wrong sending a range packet.", "ERROR", ConsoleColor.Red);
                Debug.WriteLine(e.Message, "Debug Error");
            }
        }

        public static void SendToSpacemap(Spacemap spacemap, byte[] command)
        {
            try
            {
                foreach (var entry in spacemap.Entities)
                {
                    if (entry.Value is Player)
                    {
                        World.StorageManager.GameSessions[entry.Key].Client.Send(command);
                    }
                }
            }
            catch (Exception e)
            {
                Out.WriteLine("Something went wrong sending a spacemap packet.", "ERROR", ConsoleColor.Red);
                Debug.WriteLine(e.Message, "Debug Error");

            }
        }

        public void Disconnect()
        {
            try
            {
                XSocket.Close();
            }
            catch (Exception)
            {
                Out.WriteLine("Error disconnecting user from Game", "GAME", ConsoleColor.DarkRed);
            }
        }

    }
}
