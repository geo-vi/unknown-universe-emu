﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Controller.netty;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Controller
{
    class Controller
    {
        public static List<ControllerClient> Clients = new List<ControllerClient>();

        public static void Initiate()
        {
            CommandHandler.AddCommands();
        }

        public static void Send(byte[] bytes)
        {
            try
            {
                foreach (var client in Clients)
                {
                    client.Send(bytes);
                }
            }
            catch (Exception)
            {

            }
        }
    }
}
