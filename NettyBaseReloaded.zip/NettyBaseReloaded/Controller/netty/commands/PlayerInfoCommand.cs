﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Controller.netty.commands
{
    class PlayerInfoCommand
    {
        public const short ID = 3;
        public static byte[] write(int id, string username, int rankId, int factionId, int mapId, int x, int y)
        {
            var cmd = new ByteArray(ID);
            cmd.Integer(id);
            cmd.UTF(username);
            cmd.Integer(rankId);
            cmd.Integer(factionId);
            cmd.Integer(mapId);
            cmd.Integer(x);
            cmd.Integer(y);
            return cmd.ToByteArray();
        }
    }
}
