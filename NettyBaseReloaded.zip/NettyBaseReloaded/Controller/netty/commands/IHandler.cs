﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.objects;
using NettyBaseReloaded.Networking;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Controller.netty.commands
{
    interface IHandler
    {
        void execute(ControllerClient client, ByteParser parser);
    }
}
