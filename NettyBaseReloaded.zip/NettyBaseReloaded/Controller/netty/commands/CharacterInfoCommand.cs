﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Controller.netty.commands
{
    class CharacterInfoCommand
    {
        public const short ID = 9;
        public static byte[] write(int id, string name, int mapId, int x, int y)
        {
            var cmd = new ByteArray(ID);
            cmd.Integer(id);
            cmd.UTF(name);
            cmd.Integer(mapId);
            cmd.Integer(x);
            cmd.Integer(y);
            return cmd.ToByteArray();
        }
    }
}
