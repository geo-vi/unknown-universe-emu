﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Controller.netty.commands;
using NettyBaseReloaded.Controller.netty.handlers;
using NettyBaseReloaded.Networking;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Controller.netty
{
    class CommandHandler
    {
        public static Dictionary<short, IHandler> HandledCommands = new Dictionary<short, IHandler>();

        public static void AddCommands()
        {
            HandledCommands.Add(LoginRequest.ID, new LoginHandler());
            HandledCommands.Add(MapChangeRequest.ID, new MapChangeHandler());
        }

        public static void Handle(byte[] bytes, ControllerClient client)
        {
            var parser = new ByteParser(bytes);

            if (HandledCommands.ContainsKey(parser.CMD_ID))
                HandledCommands[parser.CMD_ID].execute(client, parser);
        }
    }
}
