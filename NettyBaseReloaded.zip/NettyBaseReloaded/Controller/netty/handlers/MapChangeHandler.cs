﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NettyBaseReloaded.Controller.netty.commands;
using NettyBaseReloaded.Game;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Networking;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Controller.netty.handlers
{
    class MapChangeHandler : IHandler
    {
        public void execute(ControllerClient client, ByteParser parser)
        {
            var mapId = parser.Int();

            foreach (var entity in World.StorageManager.Spacemaps[mapId].Entities)
            {
                if (entity.Value is Player)
                {
                    var player = (Player)entity.Value;
                    client.Send(PlayerInfoCommand.write(player.Id, player.Name, (int)player.RankId,
                        (int)player.FactionId, player.Spacemap.Id, player.Position.X, player.Position.Y));
                }
                else
                {
                    client.Send(CharacterInfoCommand.write(entity.Value.Id, entity.Value.Name, entity.Value.Spacemap.Id, entity.Value.Position.X, entity.Value.Position.Y));
                }
                Thread.Sleep(100);
            }

        }
    }
}
