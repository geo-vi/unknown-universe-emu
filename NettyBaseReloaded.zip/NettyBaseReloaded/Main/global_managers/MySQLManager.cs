﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace NettyBaseReloaded.Main.global_managers
{
    class MySQLManager
    {
        /// <summary>
        /// SINGLETON USAGE
        /// </summary>
        #region SINGLETON
        public static MySQLManager INSTANCE = null;

        public static MySQLManager getInstance()
        {
            if (INSTANCE == null)
            {
                INSTANCE = new MySQLManager();
            }

            return INSTANCE;
        }

        #endregion SINGLETON   

        private MySqlConnection connection;

        public static string SERVER = "164.132.4.31";
        public static string UID = "remote";
        public static string PWD = "fuckuberorbit";
        public static string DB = "do_server_ge1";

        public MySQLManager()
        {
            try
            {
                connection = new MySqlConnection("server=" + SERVER + ";uid=" + UID + ";pwd=" + PWD + ";database=" + DB + ";");
                connection.Open();

                Out.WriteLine("MySQL Manager instance created.", "SUCCESS", ConsoleColor.Green);
            }
            catch (MySqlException e)
            {
                Out.WriteLine("MySQL Manager instance couldn't be created. Please check the \nMySQL information in the config file", "CRITIAL ERROR", ConsoleColor.Red);

                Debug.WriteLine(e.Message, "Debug Error", ConsoleColor.Red);

                //Program.Exit();
            }
        }

        /// <summary>
        /// Executes the passed MysqlCommand
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public MySqlDataReader Execute(MySqlCommand query)
        {
            try
            {
                if (connection.State == ConnectionState.Open)
                {
                    string queryType = query.CommandText.Split(' ')[0];

                    //Adds the connection to the command
                    query.Connection = connection;

                    switch (queryType)
                    {
                        case "SELECT":
                            MySqlDataAdapter adap = new MySqlDataAdapter(query);
                            DataSet set = new DataSet();

                            return query.ExecuteReader();

                        default:
                            query.ExecuteNonQuery();
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                Out.WriteLine("Something went wrong executing the query (" + query.CommandText + ")", "ERROR",
                    ConsoleColor.Red);

                Debug.WriteLine(e.Message, "Debug Error", ConsoleColor.Red);

                Out.WriteLine("Refreshing connection...");
                CloseConnection();
                getInstance(); //Creates a new instance
            }

            return null;
        }


        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                INSTANCE = null;
                return true;
            }
            catch (MySqlException e)
            {
                Out.WriteLine("Couldn't close MySQLManager connection.", "ERROR", ConsoleColor.Red);

                Debug.WriteLine(e.Message, "Debug Error", ConsoleColor.Red);
                return false;
            }
        }
    }
}
