﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Main.global_managers
{
    class QueryManager
    {
        private MySQLManager mysql = MySQLManager.getInstance();

        public void Load()
        {
            LoadClans();    
        }

        public void LoadClans()
        {
            
        }

        public void SaveAll()
        {
            
        }
    }
}
