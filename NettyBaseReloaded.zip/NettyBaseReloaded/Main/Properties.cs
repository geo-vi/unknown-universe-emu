﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Main
{
    static class Properties
    {
        /// <summary>
        /// This should be for logging server info / crashes & cause of crash.
        /// </summary>
        public static bool LOGGING = false;

        public static string LOGGING_DIRECTORY = ".\\logs\\";

        /// <summary>
        /// Is server running
        /// </summary>
        public static bool SERVER_IS_READY = false;

        /// <summary>
        /// Is server locked
        /// </summary>
        public static bool SERVER_LOCKED = false;

        /// <summary>
        /// Server password
        /// </summary>
        public static string SERVER_PW = "";

        /// <summary>
        /// Server RCON passwrd
        /// </summary>
        public static string SERVER_RCON_PW = "";

        public static int TOTAL_CONNECTED_PLAYERS = 0;

        public static bool SERVER_DEBUG = false;

    }
}
