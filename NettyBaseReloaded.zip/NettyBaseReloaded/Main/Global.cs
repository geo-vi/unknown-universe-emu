﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game;
using NettyBaseReloaded.Main.global_managers;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Main
{
    static class Global
    {
        public static QueryManager QueryManager = new QueryManager();
        public static TickManager TickManager = new TickManager();

        public static void Start()
        {
            Logger.Logger.Start();
            InitiateGlobalQueries();
            InitiateChat();
            InitiateGame();
            InitiateController();
            TickManager.Tick();
        }

        static void InitiateGlobalQueries()
        {
            QueryManager.Load();
            Logger.Logger.WritingManager.Write("Global-Queries loaded!");
        }

        static void InitiateChat()
        {
            Chat.Chat.InitiateManagers();
            new Server(Server.CHAT_PORT);

            Out.WriteLine("Chat-Server started successfully and DB loaded!", "SUCCESS", ConsoleColor.DarkGreen);
            Logger.Logger.WritingManager.Write("Chat-Server started.");
        }

        static void InitiateGame()
        {
            World.InitiateManagers();
            new Server(Server.GAME_PORT);

            Out.WriteLine("Game-Server started successfully and DB loaded!", "SUCCESS", ConsoleColor.DarkGreen);
            Logger.Logger.WritingManager.Write("Game-Server started.");
        }

        static void InitiateController()
        {
            Controller.Controller.Initiate();
            new Server(Server.CONTROLLER_PORT);
            Out.WriteLine("Controller-Server started successfully!", "SUCCESS", ConsoleColor.DarkGreen);
            Logger.Logger.WritingManager.Write("Controller-Server started.");
        }

        public static void SaveAll()
        {
            QueryManager.SaveAll();
            World.DatabaseManager.SaveAll();
        }
    }
}
