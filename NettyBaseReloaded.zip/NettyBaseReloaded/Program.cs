﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NettyBaseReloaded.Game;
using NettyBaseReloaded.Game.managers;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Main;
using NettyBaseReloaded.Main.global_managers;

namespace NettyBaseReloaded
{
    class Program
    {
        private static bool SERVER_INITIATED = false;

        static void Main(string[] args)
        {
            if (args.Contains("r")) InitiateServer();
            Load();
        }

        static void Load()
        {
            while (true)
            {
                var reader = Console.ReadLine();
                CommandParser(reader);
            }
        }

        static void Logo()
        {
            Console.Clear();
            var oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Cyan;
            string logo = @"
                   __  __      __                           
                  / / / /___  / /______  ____ _      ______ 
                 / / / / __ \/ //_/ __ \/ __ \ | /| / / __ \
                / /_/ / / / / ,< / / / / /_/ / |/ |/ / / / /
                \____/_/ /_/_/|_/_/ /_/\____/|__/|__/_/ /_/ 
                                            
                   __  __      _                         
                  / / / /___  (_)   _____  _____________ 
                 / / / / __ \/ / | / / _ \/ ___/ ___/ _ \
                / /_/ / / / / /| |/ /  __/ /  (__  )  __/
                \____/_/ /_/_/ |___/\___/_/  /____/\___/ 
                                                        
                                                        
                         ---- We are awesome! ---      
                                                        
                                                        ";
            Console.WriteLine(logo);
            Console.ForegroundColor = oldColor;
        }

        static void InitiateServer()
        {
            Console.Title = "Loading...";
            LookForConfigFiles();
            Console.Title = "Finished reading config";
            Logo();
            Console.Title = "Starting servers";
            Global.Start();
            Console.Title = "Unknown Universe: 2.0.0";
        }

        static void LookForConfigFiles()
        {
           if (File.Exists(Directory.GetCurrentDirectory() + "/server.cfg")) ConfigFileReader.ReadServerConfig();
           if (File.Exists(Directory.GetCurrentDirectory() + "/game.cfg")) ConfigFileReader.ReadGameConfig();
           if (File.Exists(Directory.GetCurrentDirectory() + "/mysql.cfg")) ConfigFileReader.ReadMySQLConfig();
        }

        static void CommandParser(string input)
        {
            if (input == "" && SERVER_INITIATED) return;
            if (input == "" && !SERVER_INITIATED) InitiateServer();

            if (input.Contains(' '))
            {
                var inputSplit = input.Split(' ');
                switch (inputSplit[0])
                {
                    case "/spawn":
                        switch (inputSplit[1])
                        {
                            case "npcs":
                                if (inputSplit[2] == "all")
                                {
                                    foreach (var map in World.StorageManager.Spacemaps.Values)
                                    {
                                        map.SpawnNpcs(true);
                                    }
                                }
                                var targetMap = World.StorageManager.Spacemaps[Convert.ToInt32(inputSplit[2])];
                                targetMap?.SpawnNpcs(true);
                                break;
                        }
                        break;
                    case "/global":

                        break;
                    case "/log":
                        switch (inputSplit[1])
                        {
                            case "add":
                            case "write":
                                //Logger.Logger.WritingManager.Write(inputSplit[2]);
                                //Console.WriteLine("{0} has been added to log.", inputSplit[2]);
                                Console.WriteLine("Not functioning yet.");
                                break;
                            case "readall":
                                Console.WriteLine(Logger.Logger.ReadingManager.ReadAll());
                                break;
                            case "search":
                                Console.WriteLine(Logger.Logger.ReadingManager.Read(inputSplit[2]));
                                break;
                            case "lookbytime":
                                Console.WriteLine(Logger.Logger.ReadingManager.ReadByTime(inputSplit[2]));
                                break;
                            case "lookbyid":
                                Console.WriteLine(Logger.Logger.ReadingManager.Read(Convert.ToInt32(inputSplit[2])));
                                break;
                            default:
                                Console.WriteLine("/log [readall / search [Content] / lookbytime [Time] / lookbyid [UserId]");
                                break;
                        }
                        break;
                }
            }
            else
            {
                switch (input)
                {
                    case "/lock":
                        break;
                    case "/clear":
                    case "/clean":
                        Console.Clear();
                        Logo();
                        break;
                    case "/cleanall":
                        Console.Clear();
                        break;
                    case "/close":
                        Global.SaveAll();
                        Thread.Sleep(1000);
                        Environment.Exit(1);
                        break;
                }
            }
        }
    }
}
