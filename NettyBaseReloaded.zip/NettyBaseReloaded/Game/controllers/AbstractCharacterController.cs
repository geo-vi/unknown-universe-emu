﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty;
using NettyBaseReloaded.Game.netty.commands;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Game.objects.world.storages.playerStorages;
using NettyBaseReloaded.Main;
using NettyBaseReloaded.Main.interfaces;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Game.controllers
{
    class AbstractCharacterController : ITick
    {
        public Character Character { get; }

        public CooldownStorage CooldownStorage { get; set; }

        public bool Dead { get; set; }

        public bool StopController { get; set; }

        public bool Attacking { get; set; }

        public bool Attacked { get; set; }

        public bool Invincible { get; set; }

        public bool Targetable { get; set; }

        public int AttackRange = 700;

        public AbstractCharacterController(Character character)
        {
            Character = character;

            Dead = false;
            StopController = false;
            Attacking = false;
            Attacked = false;
            Invincible = false;
            Targetable = true;

            CooldownStorage = new CooldownStorage();
        }

        public void Tick()
        {
            if (StopController) return;
            if (Attacking) LaserAttack();

            if (this is NpcController)
            {
                var npc = (Npc)Character;
                npc.Controller?.Tick();
                return;
            }

            if (this is PlayerController)
            {
                var player = (Player) Character;
                player.Controller?.Tick();
                return;
            }

            Checkers();

        }

        #region Checkers
        public void Checkers()
        {
            if (!Character.Position.Equals(Character.Destination))
            {
                MovementController.ActualPosition(Character);
            }

            CharacterChecker();
            CollectableChecker();
        }

        public void CharacterChecker()
        {
            foreach (var entry in Character.Spacemap.Entities)
            {
                try
                {
                    var entity = entry.Value;
                    //If i have the entity in range
                    if (Character.InRange(entity))
                    {
                        AddCharacter(Character, entity);
                    }
                    else
                    {
                        RemoveCharacter(Character, entity);
                    }

                    //If the entity has me in range
                    if (entity.InRange(Character))
                    {
                        AddCharacter(entity, Character);
                    }
                    else
                    {
                        //remove
                        RemoveCharacter(entity, Character);
                    }
                }
                catch (Exception)
                {

                }
            }
        }

        private void CollectableChecker()
        {
            //if (Character is Npc || Character.Spacemap.Collectables.Count <= 0)
            //    return;

            //foreach (var collectable in Character.Spacemap.Collectables)
            //{
            //    if (Vector.IsInRange(collectable.Value.Position, Character.Position, 2000))
            //    {
            //        if (Character.RangeCollectables.ContainsKey(collectable.Key))
            //            return;

            //        if (Character is Player)
            //        {
            //            ServerManager.GameSessions[Character.Id].Client.Send(PacketBuilder.LegacyModule(collectable.Value.ToString()));
            //        }

            //        Character.RangeCollectables.Add(collectable.Key, collectable.Value);
            //    }
            //    else
            //    {
            //        if (Character.RangeCollectables.ContainsKey(collectable.Key))
            //        {
            //            if (Character is Player)
            //            {
            //                World.StorageManager.GameSessions[Character.Id].Client.Send(PacketBuilder.LegacyModule("0|2|" + collectable.Key));
            //            }

            //            Character.RangeCollectables.Remove(collectable.Key);
            //        }
            //    }
            //}
        }
        #endregion
        #region Range
        private void AddCharacter(Character main, Character entity)
        {
            if (!main.RangeEntities.ContainsKey(entity.Id))
            {
                main.RangeEntities[entity.Id] = entity;
                if (!(main is Player)) return;
                //if (entity is Pet)
                //{
                //    var pet = (Pet)entity;
                //    if (main.Id == pet.OwnerId)
                //        return;
                //}

                var client = World.StorageManager.GameSessions[main.Id].Client;

                //Draws the entity ship for character

                client.Send(PacketBuilder.ShipCreateCommand(entity));
                client.Send(PacketBuilder.DronesCommand(entity));

                //Send movement
                var timeElapsed = (DateTime.Now - Character.MovementStartTime).TotalMilliseconds;
                client.Send(PacketBuilder.MoveCommand(Character.Id, Character.Destination,
                    (int)(Character.MovementTime - timeElapsed)));

            }
        }

        /// <summary>
        /// Removes entity for main character
        /// </summary>
        /// <param name="main"></param>
        /// <param name="entity"></param>
        private void RemoveCharacter(Character main, Character entity)
        {
            if (entity.RangeEntities.ContainsKey(main.Id))
            {
                entity.RangeEntities.Remove(main.Id);
                if (!(entity is Player)) return;
                //if (main is Pet)
                //{
                //    var pet = (Pet)main;
                //    if (entity.Id == pet.OwnerId)
                //        return;
                //}

                var client = World.StorageManager.GameSessions[entity.Id].Client;

                client.Send(PacketBuilder.ShipRemoveCommand(main.Id));
                if (main.Selected != null && main.Selected.Id == entity.Id)
                {
                    client.Send(PacketBuilder.ShipSelectionCommand(null));
                    main.Selected = null;
                }
            }
        }
        #endregion

        #region Attack
        public Character GetAttacker()
        {
            foreach (var entity in Character.RangeEntities.Values)
            {
                if (entity.Controller.Dead) return null;
                if (entity.Selected == Character && entity.Controller.Attacking)
                {
                    return entity;
                }
            }
            return null;
        }

        public void LaserAttack()
        {
            #region Alive Check

            if (Dead || StopController) // Self check
                return;

            var enemy = Character.Selected;

            if (enemy == null) return;
            if (enemy.Controller.Dead || enemy.Controller.StopController) // Enemy check
                return;

            #endregion

            if (!CooldownStorage.Finished(CooldownStorage.LASER_COOLDOWN))
                return;


            if (Character.InRange(Character.Selected, 700))
            {
                if (Character is Player)
                {
                    var player = (Player)Character;

                    if (player.LaserCount() == 0)
                    {
                        World.StorageManager.GetGameSession(player.Id)
                            .Client.Send(PacketBuilder.LegacyModule("0|A|STM|msg_laser_not_equipped"));
                        return;
                    }

                    player.Controller.Repairing = false;
                    if (Character.Selected is Player) ((Player)Character.Selected).Controller.Repairing = false;

                    enemy.Controller.Attacked = true;
                    enemy.LastCombatTime = DateTime.Now;
                    Character.LastCombatTime = DateTime.Now;
                    CooldownStorage.LaserCooldownEnd = DateTime.Now.AddSeconds(1);

                    switch (player.Settings.Slotbar.SelectedLaser)
                    {
                        case AmmunitionTypeModule.X1:
                            if (player.CurrentAmmo.LCB_10 < player.LaserCount()) return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 0, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage), false);
                            break;
                        case AmmunitionTypeModule.X2:
                            if (player.CurrentAmmo.MCB_25 < player.LaserCount()) return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 1, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage * 2), false);
                            break;
                        case AmmunitionTypeModule.X3:
                            if (player.CurrentAmmo.MCB_50 < player.LaserCount()) return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 2, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage * 3), false);
                            break;
                        case AmmunitionTypeModule.X4:
                            if (player.CurrentAmmo.UCB_100 < player.LaserCount()) return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 3, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage * 4), false);
                            break;
                        case AmmunitionTypeModule.SAB:
                            if (player.CurrentAmmo.SAB_50 < player.LaserCount()) return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 4, false, true),
                                true);
                            Absorb(Character.Damage);
                            break;
                        case AmmunitionTypeModule.CBO:
                            if (player.CurrentAmmo.CBO_100 < player.LaserCount()) return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 8, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage * 3), false);
                            Absorb((int)(Character.Damage * 0.25));
                            break;
                        case AmmunitionTypeModule.RSB:
                            if (player.CurrentAmmo.RSB_75 < player.LaserCount()) return;

                            if (!CooldownStorage.Finished(CooldownStorage.RSB_COOLDOWN))
                                return;
                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 6, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage * 6), false);
                            CooldownStorage.Start(World.StorageManager.GetGameSession(Character.Id), CooldownStorage.RSB_COOLDOWN);
                            break;
                        case AmmunitionTypeModule.JOB100:
                            if (player.CurrentAmmo.JOB_100 < player.LaserCount()) return;

                            GameClient.SendRangePacket(Character,
                                AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 9, false, true),
                                true);
                            Damage(new AttackTypeModule(AttackTypeModule.LASER), Character.Damage * 4, false);
                            break;
                    }

                    player.SpentAmmo.Add((short)player.Settings.Slotbar.SelectedLaser, player.LaserCount());
                }
                else
                {
                    GameClient.SendRangePacket(Character,
                        AttackLaserRunCommand.write(Character.Id, Character.Selected.Id, 0, false, false), true);

                    Damage(new AttackTypeModule(AttackTypeModule.LASER), RandomizeDamage(Character.Damage), false);
                }
            }
        }

        public void LaunchMissle(AttackTypeModule type = null)
        {
            if (Character.Selected == null || !CooldownStorage.Finished(CooldownStorage.ROCKET_COOLDOWN)) return;

            if (Character.InRange(Character.Selected, AttackRange))
            {

                AttackTypeModule selectedRocketType = type;
                int damage = 0;
                if (Character is Player)
                {
                    var player = (Player)Character;
                    if (selectedRocketType == null)
                    {
                        selectedRocketType = new AttackTypeModule((short)player.Settings.Slotbar.SelectedRocket);
                    }
                }
                else
                {
                    if (selectedRocketType == null)
                    {
                        return;
                    }
                }

                switch (selectedRocketType.type)
                {
                    case AmmunitionTypeModule.R310:
                        GameClient.SendRangePacket(Character,
                            PacketBuilder.LegacyModule("0|v|" + Character.Id + "|" + Character.Selected.Id + "|H|1|0|0"),
                            true);
                        Damage(new AttackTypeModule(AttackTypeModule.ROCKET), RandomizeDamage(Character.RocketDamage, 0.5), false);
                        break;
                    case AmmunitionTypeModule.PLT2026:
                        GameClient.SendRangePacket(Character,
                            PacketBuilder.LegacyModule("0|v|" + Character.Id + "|" + Character.Selected.Id + "|H|2|0|0"),
                            true);
                        Damage(new AttackTypeModule(AttackTypeModule.ROCKET), RandomizeDamage(Character.RocketDamage * 2), false);
                        break;
                    case AmmunitionTypeModule.PLT2021:
                        GameClient.SendRangePacket(Character,
                            PacketBuilder.LegacyModule("0|v|" + Character.Id + "|" + Character.Selected.Id + "|H|3|0|0"),
                            true);
                        Damage(new AttackTypeModule(AttackTypeModule.ROCKET), RandomizeDamage(Character.RocketDamage * 3, 1.50), false);
                        break;
                    case AmmunitionTypeModule.PLT3030:
                        GameClient.SendRangePacket(Character,
                            PacketBuilder.LegacyModule("0|v|" + Character.Id + "|" + Character.Selected.Id + "|H|4|0|0"),
                            true);
                        Damage(new AttackTypeModule(AttackTypeModule.ROCKET), RandomizeDamage(Character.RocketDamage * 4, 2.00), false);
                        break;
                }
                CooldownStorage.Start(World.StorageManager.GetGameSession(Character.Id), CooldownStorage.ROCKET_COOLDOWN);
            }
        }

        private int RandomizeDamage(int baseDmg, double missProbability = 1.00)
        {
            var random = new Random();
            var randNums = random.Next(0, 5);

            if (missProbability < 1.00)
                randNums = random.Next(0, 7);
            if (missProbability > 1.00 && missProbability < 2.00)
                randNums = random.Next(0, 4);
            if (missProbability >= 2.00)
                randNums = random.Next(2, 4);

            switch (randNums)
            {
                case 0:
                    return (int) (baseDmg*1.10);
                case 1:
                    return (int) (baseDmg*0.98);
                case 2:
                    return (int)(baseDmg*1.02);
                case 3:
                    return 0;
                case 4:
                    return (int)(baseDmg * 0.92);
                case 5:
                    return (int) (baseDmg*0.99);
                default:
                    return baseDmg;
            }
        }

        public void Damage(AttackTypeModule attackType, int damage = 0, bool directHit = false)
        {
            var enemy = Character.Selected;
            if (enemy == null) return;

            Character.LastCombatTime = DateTime.Now;
            enemy.LastCombatTime = DateTime.Now;

            if (enemy.Controller.Invincible) damage = 0;

            if (Character is Player)
            {
                if (damage != 0)
                    World.StorageManager.GetGameSession(Character.Id).Client.Send(AttackHitCommand.write(attackType, Character.Id, enemy.Id, enemy.CurrentHealth, enemy.CurrentShield,
                        enemy.CurrentNanoHull, damage, true));
                else
                    World.StorageManager.GetGameSession(Character.Id).Client.Send(AttackMissedCommand.write(attackType, enemy.Id, 0));
            }

            if (enemy is Player)
            {
                if (damage != 0)
                    World.StorageManager.GetGameSession(enemy.Id).Client.Send(AttackHitCommand.write(attackType, Character.Id, enemy.Id, enemy.CurrentHealth, enemy.CurrentShield,
                        enemy.CurrentNanoHull, damage, true));
                else
                    World.StorageManager.GetGameSession(enemy.Id).Client.Send(AttackMissedCommand.write(attackType, enemy.Id, 0));
            }

            switch (attackType.type)
            {
                case AttackTypeModule.LASER:
                case AttackTypeModule.ROCKET:
                    if (directHit)
                    {
                        enemy.CurrentHealth -= damage;
                    }
                    else
                    {
                        var totalAbs = Math.Abs(enemy.ShieldPenetration - enemy.ShieldAbsorption);

                        if (enemy.CurrentShield >= 1)
                        {
                            enemy.CurrentShield -= (int)(damage);
                            enemy.CurrentHealth -= (int)(totalAbs);
                        }
                        else
                        {
                            enemy.CurrentHealth -= damage;
                        }
                    }

                    if (enemy.CurrentHealth <= 0)
                        Destroy(enemy);
                    break;
            }
        }

        public void Damage(AttackTypeModule attackType, int amount, int distance = 0, DamageType damageType = DamageType.DEFINED)
        {
            if (distance == 0) distance = AttackRange;

            foreach (var entry in Character.Spacemap.Entities)
            {
                if (entry.Value.Controller.Invincible) return;
                if (Character.Position.DistanceTo(entry.Value.Position) > distance) return;
                if (Character.Id == entry.Value.Id) continue;
                var ctrl = entry.Value.Controller as PlayerController;
                if (ctrl != null)
                {
                    var playerCtrl = ctrl;
                    if (playerCtrl.Repairing)
                        playerCtrl.Repairing = false;
                }

                var damage = 0;
                switch (damageType)
                {
                    case DamageType.DEFINED:
                        damage = amount;
                        break;
                    case DamageType.PERCENTAGE:
                        damage = entry.Value.CurrentHealth * amount / 100;
                        break;
                }

                entry.Value.CurrentHealth -= damage;
                entry.Value.LastCombatTime = DateTime.Now;
                if (entry.Value is Player) World.StorageManager.GameSessions[entry.Value.Id].Client.Send(AttackHitCommand.write(attackType, Character.Id, entry.Value.Id, entry.Value.CurrentHealth, entry.Value.CurrentShield,
                    entry.Value.CurrentNanoHull, damage, true));

                if (Character is Player) World.StorageManager.GameSessions[Character.Id].Client.Send(AttackHitCommand.write(attackType, Character.Id, entry.Value.Id, entry.Value.CurrentHealth, entry.Value.CurrentShield,
                    entry.Value.CurrentNanoHull, damage, true));

                Character.LastCombatTime = DateTime.Now;
                entry.Value.LastCombatTime = DateTime.Now;
            }

        }

        public void Absorb(int amount)
        {
            var enemy = Character.Selected;
            if (enemy == null) return;

            if (enemy.CurrentShield - amount < 0)
                enemy.CurrentShield = 0;
            else enemy.CurrentShield -= amount;

            Character.CurrentShield += amount;

            World.StorageManager.GameSessions[Character.Id].Client.Send(
                AttackHitCommand.write(new AttackTypeModule(AttackTypeModule.LASER), Character.Id, enemy.Id,
                    enemy.CurrentHealth, enemy.CurrentShield,
                    enemy.CurrentNanoHull, amount, false));


            Character.LastCombatTime = DateTime.Now;
            enemy.LastCombatTime = DateTime.Now;
        }

        public void Heal(int amount, int healerId = 0, HealType healType = HealType.HEALTH)
        {
            if (amount < 0)
                return;

            var newAmount = amount;
            var oldHp = Character.CurrentHealth;
            var oldShd = Character.CurrentShield;

            switch (healType)
            {
                case HealType.HEALTH:
                    if (Character.CurrentHealth + amount > Character.MaxHealth)
                    {
                        newAmount = (Character.CurrentHealth + amount) - Character.MaxHealth;
                    }
                    Character.CurrentHealth += newAmount;
                    break;
                case HealType.SHIELD:
                    if (Character.CurrentShield + amount > Character.MaxShield)
                    {
                        newAmount = (Character.CurrentShield + amount) - Character.MaxShield;
                    }
                    Character.CurrentShield += newAmount;
                    break;
            }

            if (Character is Player && healType == HealType.HEALTH) World.StorageManager.GetGameSession(Character.Id).Client.Send(
                PacketBuilder.LegacyModule("0|A|HL||" + Character.Id + "|HPT|" + oldHp + "|" + newAmount));
            else if (Character is Player && healType == HealType.SHIELD) World.StorageManager.GetGameSession(Character.Id).Client.Send(
                PacketBuilder.LegacyModule("0|A|HL||" + Character.Id + "|SHD|" + oldShd + "|" + newAmount));

        }
        #endregion

        #region Destruction

        public void Destroy(Character targetCharacter)
        {
            if (targetCharacter == null)
                return;

            Deselect(targetCharacter);
            GameClient.SendRangePacket(targetCharacter, ShipDestroyedCommand.write(targetCharacter.Id, 0), true);
            Character.Spacemap.CreateShipLoot(targetCharacter.Position, targetCharacter.DropableRewards);

            if (Character is Player)
            {
                var player = (Player)Character;
                player.Stats.Destroy(targetCharacter.Hangar.Ship);
                //player.RewardPlayer(targetCharacter.BasicRewards);
            }

            if (targetCharacter.Moving)
            {
                MovementController.Move(targetCharacter, MovementController.ActualPosition(targetCharacter));
            }

            targetCharacter.CurrentShield = 0;
            targetCharacter.CurrentHealth = 0;
            targetCharacter.Controller.Attacking = false;
            targetCharacter.Selected = null;
            targetCharacter.Controller.Dead = true;
            targetCharacter.Controller.StopController = true;

            if (Character.Spacemap.Entities.ContainsKey(targetCharacter.Id))
                Character.Spacemap.Entities.Remove(targetCharacter.Id);

            foreach (var user in Character.Spacemap.Entities.Values)
            {
                RemoveCharacter(targetCharacter, user);
            }

            if (targetCharacter is Npc)
            {
                ((NpcController)targetCharacter.Controller).Kill();
                targetCharacter.Controller.Respawn();
            }
            else if (targetCharacter is Player)
            {
                var localized = new MessageLocalizedWildcardCommand("", new List<MessageWildcardReplacementModule>());
                var options = new List<KillScreenOptionModule>
                {
                    new KillScreenOptionModule(new KillScreenOptionTypeModule(KillScreenOptionTypeModule.BASIC_REPAIR),
                        new PriceModule(PriceModule.URIDIUM, 0), true,
                        3, localized, localized, localized, localized)

                    //new KillScreenOptionModule(new KillScreenOptionTypeModule(KillScreenOptionTypeModule.AT_JUMPGATE_REPAIR),
                    //    new PriceModule(PriceModule.URIDIUM, 699), true,
                    //    6, localized, localized, localized, localized),

                    //new KillScreenOptionModule(new KillScreenOptionTypeModule(KillScreenOptionTypeModule.AT_DEATHLOCATION_REPAIR),
                    //    new PriceModule(PriceModule.URIDIUM, 1699), true,
                    //    9, localized, localized, localized, localized)

                };

                World.StorageManager.GetGameSession(targetCharacter.Id).Client.Send(KillScreenPostCommand.write("swag", "", "3rd leg",
                    new DestructionTypeModule(DestructionTypeModule.PLAYER), options));
            }
            else
            {
                // TODO: Killed PET
            }
        }

        public void Remove(Character targetCharacter)
        {
            if (targetCharacter == null)
                return;

            targetCharacter.Spacemap.Entities.Remove(targetCharacter.Id);

            if (targetCharacter is Player)
            {
                var player = (Player)targetCharacter;
                //player.BasicSave();
            }

            foreach (var user in targetCharacter.Spacemap.Entities.Values)
            {
                RemoveCharacter(targetCharacter, user);
            }
            targetCharacter.Controller.StopController = true;
        }

        public void Deselect(Character targetCharacter)
        {
            if (targetCharacter == null)
                return;

            foreach (var entity in targetCharacter.Spacemap.Entities)
            {
                if (entity.Value.Selected != null && entity.Value.Selected == targetCharacter)
                {
                    if (entity.Value.Controller != null)
                    {
                        if (entity.Value.Controller.Attacking)
                        {
                            entity.Value.Controller.Attacking = false;
                        }
                    }

                    if (entity.Value is Player)
                    {
                        World.StorageManager.GetGameSession(entity.Value.Id).Client.Send(PacketBuilder.ShipSelectionCommand(null));
                        World.StorageManager.GetGameSession(entity.Value.Id).Client.Send(PacketBuilder.ShipDeselectionCommand());
                    }

                    entity.Value.Selected = null;
                }
            }
        }

        public void Respawn()
        {
            Dead = false;
            StopController = false;
            Attacking = false;

            if (!Character.Spacemap.Entities.ContainsKey(Character.Id))
                Character.Spacemap.Entities.Add(Character.Id, Character);

            if (Character is Npc)
            {
                var npc = (Npc)Character;
                npc.CurrentHealth = npc.MaxHealth;
                npc.CurrentShield = npc.MaxShield;
                npc.Position = Vector.Random(1000, 28000, 1000, 12000);

                npc.Controller.Start();
            }
            else if (Character is Player)
            {
                var player = (Player)Character;
                player.CurrentHealth = 1000;

                if (player.Controller == null)
                    player.Controller = new PlayerController(Character);

                player.Controller.Start();
            }

            Character.RangeEntities.Clear();
        }

        #endregion
    }
}
