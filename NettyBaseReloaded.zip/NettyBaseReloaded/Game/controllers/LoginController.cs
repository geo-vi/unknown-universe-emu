﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty;
using NettyBaseReloaded.Game.netty.commands;
using NettyBaseReloaded.Game.objects;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Game.objects.world.map.assets;
using NettyBaseReloaded.Game.objects.world.players;
using NettyBaseReloaded.Main;
using NettyBaseReloaded.Main.global_managers;

namespace NettyBaseReloaded.Game.controllers
{
    class LoginController
    {
        public static void Respawn(GameSession gameSession)
        {
            gameSession.Player.CurrentHealth = 1000;
            NormalSpawn(gameSession);
        }

        public static void Login(GameSession gameSession)
        {
            var player = gameSession.Player;
           
            if (player.Id == 249 || player.Id == 250)
            {

                if (!player.Spacemap.Entities.ContainsKey(player.Id))
                {
                    player.Spacemap.Entities.Add(player.Id, player);
                    //Start controller
                    if (player.Controller == null) 
                        player.Controller = new PlayerController(player);
                }
                else
                {
                    Logger.Logger.WritingManager.Write("Player #" + player.Id +
                                                       " already exists on the Spacemap (LoginManager)");
                }


                if (Properties.SERVER_LOCKED)
                {
                    LockedServerSpawn(gameSession);
                    return;
                }

                if (player.CurrentHealth <= 0)
                {
                    ShowKillscreen(gameSession);
                    return;
                }

                NormalSpawn(gameSession);
            }
        }

        private static void UserSettings(GameSession gameSession)
        {
            var client = gameSession.Client;
            var player = gameSession.Player;

            client.Send(UserSettingsCommand.write(player.Settings.QualitySettingsModule, player.Settings.DisplaySettingsModule, player.Settings.AudioSettingsModule,
            player.Settings.WindowSettingsModule, player.Settings.GameplaySettingsModule));

            client.Send(ShipSettingsCommand.write(player.Settings.Slotbar.QuickbarSlots, player.Settings.Slotbar.QuickbarSlotsPremium,
                player.Settings.Slotbar.SelectedLaser, player.Settings.Slotbar.SelectedRocket, player.Settings.Slotbar.SelectedHellstormRocket));

            client.Send(PacketBuilder.DronesCommand(player));

            client.Send(PacketBuilder.ShipInitializationCommand(player));
        }

        private static void LockedServerSpawn(GameSession gameSession)
        {
            var client = gameSession.Client;

            UserSettings(gameSession);

            client.Send(CameraLockToCoordinatesCommand.write(0, 0, 1));

            client.Send(PacketBuilder.LegacyModule("0|A|STD|SERVER IS LOCKED"));

        }

        private static void LoadConfigurations(GameSession gameSession)
        {
            var player = gameSession.Player;

            player.Hangar = World.DatabaseManager.LoadHangar(player);
            player.Hangar.Configurations = World.DatabaseManager.LoadConfig(player);
            player.Hangar.Drones = World.DatabaseManager.LoadDrones(player);
            //player.CurrentAmmo = World.DatabaseManager.LoadAmmo(player);

        }

        private static void NormalSpawn(GameSession gameSession)
        {
            MapChecker(gameSession);
            LoadConfigurations(gameSession);
            UserSettings(gameSession);
            InitiateLegacy(gameSession);
            ShipFx(gameSession);
            LoadPortals(gameSession);
            LoadAssets(gameSession);
            LoadStations(gameSession);
            
            LoadPlayerAmmo(gameSession);

            LoadTicks(gameSession);

            Logger.Logger.WritingManager.Write("User logged in [ID: " + gameSession.Player.Id + ", Name: " + gameSession.Player.Name + "]");
        }

        private static void LoadTicks(GameSession gameSession)
        {
            var player = gameSession.Player;

            if (!Global.TickManager.Tickables.Contains(player))
                Global.TickManager.Tickables.Add(player);

            if (!Global.TickManager.Tickables.Contains(player.Controller))
                Global.TickManager.Tickables.Add(player.Controller);

            player.Controller.Start();
        }

        private static void ShipFx(GameSession gameSession)
        {
            //var client = gameSession.Client;
            //var player = gameSession.Player;

            //switch (player.Hangar.Ship.Id)
            //{
            //    case 9:
            //        client.Send(PacketBuilder.LegacyModule("0|n|fx|||"));
            //        break;
            //}
        }

        private static void MapChecker(GameSession gameSession)
        {
            if (gameSession.Player.Spacemap.Id == 0)
            {
                switch (gameSession.Player.FactionId)
                {
                    case Faction.MMO:
                        gameSession.Player.Spacemap = World.StorageManager.Spacemaps[1];
                        gameSession.Player.Position = new Vector(1000, 1000);
                        break;
                    case Faction.EIC:
                        gameSession.Player.Spacemap = World.StorageManager.Spacemaps[5];
                        gameSession.Player.Position = new Vector(19800, 1000);
                        break;
                    case Faction.VRU:
                        gameSession.Player.Spacemap = World.StorageManager.Spacemaps[9];
                        gameSession.Player.Position = new Vector(19800, 11800);
                        break;

                }
            }
        }

        private static void InitiateLegacy(GameSession gameSession)
        {
            var player = gameSession.Player;
            var client = gameSession.Client;

            client.Send(CameraLockToHeroCommand.write());
            client.Send(PacketBuilder.LegacyModule("0|A|" + ServerCommands.SERVER_VERSION + "|2.0.0 (NEW CORE - BETA)"));
            client.Send(PacketBuilder.BigMessage("beta_splash_text"));

            client.Send(PacketBuilder.LegacyModule("0|A|ITM|" + player.GetConsumablesPacket()));
            client.Send(PacketBuilder.LegacyModule("0|A|BK|" + player.BootyKeys[0])); //green booty
            client.Send(PacketBuilder.LegacyModule("0|A|BKR|" + player.BootyKeys[1])); //red booty
            client.Send(PacketBuilder.LegacyModule("0|A|BKB|" + player.BootyKeys[2])); //blue booty
            client.Send(PacketBuilder.LegacyModule("0|TR"));
            client.Send(PacketBuilder.LegacyModule("0|A|CC|" + player.CurrentConfig));
            client.Send(PacketBuilder.LegacyModule("0|ps|nüscht|"));
            client.Send(PacketBuilder.LegacyModule("0|ps|blk|0"));
            client.Send(PacketBuilder.LegacyModule("0|n|w|-1")); //enemy warning
            client.Send(PacketBuilder.LegacyModule("0|g|a|b,1000,1,10000.0,C,2,500.0,U,3,1000.0,U,5,1000.0,U|r,100,1,10000,C,2,50000,C,3,500.0,U,4,700.0,"));
            //client.Send(PacketBuilder.LegacyModule("0|UI|MM|SM|0|6000|2000|1"));
        }

        /// <summary>
        /// Load all the portals of the map
        /// </summary>
        /// <param name="gameSession"></param>
        private static void LoadPortals(GameSession gameSession)
        {
            foreach (var portal in gameSession.Player.Spacemap.Portals.Values)
            {
                gameSession.Client.Send(PacketBuilder.LegacyModule(portal.ToString()));
            }
        }

        private static void LoadAssets(GameSession gameSession)
        {
            List<QuestGiverModule> questGivers = new List<QuestGiverModule>();
            foreach (var asset in gameSession.Player.Spacemap.Assets.Values)
            {
                //if (asset is QuestGiver)
                //{
                //    var qg = (QuestGiver)asset;
                //    questGivers.Add(new QuestGiverModule(qg.QuestGiverId, qg.Id));
                //}
                gameSession.Client.Send(PacketBuilder.CreateAsset(asset));
            }
            gameSession.Client.Send(QuestGiversAvailableCommand.write(questGivers));
        }

        private static void LoadStations(GameSession gameSession)
        {
            foreach (var station in gameSession.Player.Spacemap.Stations)
            {
                gameSession.Client.Send(PacketBuilder.LegacyModule(station.GetString()));
            }
        }

        private static void ShowKillscreen(GameSession gameSession)
        {
            
        }

        private static void LoadPlayerAmmo(GameSession gameSession)
        {
            gameSession.Player.CurrentAmmo = new Ammo(999,999,999,999,999, 0,999,0,999,999,999,999,999,0);
            gameSession.Client.Send(gameSession.Player.CurrentAmmo.GetPacket());
        }
    }
}
