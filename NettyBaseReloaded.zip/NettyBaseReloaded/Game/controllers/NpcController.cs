﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Controller.netty.commands;
using NettyBaseReloaded.Game.objects.world;

namespace NettyBaseReloaded.Game.controllers
{
    class NpcController : AbstractCharacterController
    {
        public AILevels AILevel { get; private set; }

        private bool Active { get; set; }

        private bool Fleeing { get; set; }

        public NpcController(Character character, AILevels ai) : base(character)
        {
            AILevel = ai;
        }

        public void ChangeAI(AILevels newAiLevel)
        {
            AILevel = newAiLevel;
        }

        public void Tick()
        {
            Checkers();
            Status();
            UpdateController();
        }

        public void UpdateController()
        {
            Controller.Controller.Send(CharacterInfoCommand.write(Character.Id, Character.Name, Character.Spacemap.Id,
                Character.Position.X, Character.Position.Y));
        }

        void Status()
        {
            if (!Active) Search();
            if (Character.Selected != null) Active = true;
            if (Character.CurrentHealth < Character.MaxHealth * 0.1)
            {
                Flee();
            }
            if (Active)
            {
                Move();
                AggresivityCheck();
            }
        }

        public void Start()
        {
            switch (AILevel)
            {
                case AILevels.PASSIVE:
                case AILevels.AGGRESSIVE:
                    Search();
                    break;
                case AILevels.GALAXY_GATES:
                    Move();
                    break;

            }
        }

        public void Kill()
        {
            
        }

        public void Respawn()
        {
            
        }

        void Search()
        {
            if (Active || Character.Selected != null)
                return;

            Character closestCharacter = null;

            if (Character.RangeEntities.Count <= 0) return;
            foreach (var character in Character.RangeEntities.Values)
            {
                if (character is Player)
                {
                    if (closestCharacter == null)
                        closestCharacter = character;
                    else
                        closestCharacter = Character.Position.GetCloserCharacter(closestCharacter, character);


                }
            }

            Character.Selected = closestCharacter;
        }

        void Move()
        {
            if (!Active)
                return;

            var target = Character.Selected;
            if (!Character.InRange(target, 3000))
            {
                Active = false;
                Character.Selected = null;
                return;
            }

            var randomX = new System.Random();
            var randomY = new System.Random();

            int targetX = Convert.ToInt32(target.Position.X + 350 * Math.Cos(randomX.Next(0, 180) * Math.PI / 180));
            int targetY = Convert.ToInt32(target.Position.Y + 350 * Math.Sin(randomY.Next(0, 180) * Math.PI / 180));
            var targetPos = new Vector(targetX, targetY);

            if (Vector.IsPositionInCircle(Character.Position, target.Position, 350))
                return;

            MovementController.Move(Character, targetPos);
        }

        void Flee()
        {
            Fleeing = true;

            var fleePos = new Vector(0, 0);
            switch (AILevel)
            {
                case AILevels.PASSIVE:
                case AILevels.AGGRESSIVE:
                    fleePos = Vector.Random(0, 20800, 0, 12800);
                    break;
                case AILevels.GALAXY_GATES:
                    fleePos = Character.Position.GetCloserVector(new Vector(0, 0), new Vector(20800, 12800));
                    break;
            }
            MovementController.Move(Character, fleePos);
        }

        void AggresivityCheck()
        {
            switch (AILevel)
            {
                case AILevels.PASSIVE:
                    if (Attacked)
                    {
                        var attacker = GetAttacker();
                        if (attacker != null)
                        {
                            Character.Selected = attacker;
                            AttackEnemy();
                        }
                    }
                    break;
                case AILevels.AGGRESSIVE:
                    AttackEnemy();
                    break;
            }
        }

        public void AttackEnemy()
        {
            
        }
    }
}
