﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Controller.netty.commands;
using NettyBaseReloaded.Game.netty;
using NettyBaseReloaded.Game.netty.commands;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Main.global_managers;

namespace NettyBaseReloaded.Game.controllers
{
    class PlayerController : AbstractCharacterController
    {
        public bool Repairing { get; set; }

        public bool Jumping { get; set; }

        public PlayerController(Character character) : base(character)
        {
            Repairing = false;
            Jumping = false;
        }

        public void Start()
        {

        }

        public void Tick()
        {
            UpdateController();
            Checkers();
            if (!Jumping)
            {
                RangePortals();
                RangeStations();
                PortalsRangeStatus();
                BeaconUpdate();
            }
        }

        public void UpdateController()
        {
            var player = (Player) Character;
            Controller.Controller.Send(PlayerInfoCommand.write(player.Id, player.Name, (int)player.RankId, (int) player.FactionId, player.Spacemap.Id, player.Position.X, player.Position.Y));
        }

        private void RangePortals()
        {
            var player = (Player)Character;

            foreach (var portal in Character.Spacemap.Portals)
            {
                if (Vector.IsInRange(portal.Value.Position, Character.Position, 1000))
                {
                    if (!player.RangePortals.ContainsKey(portal.Key))
                        player.RangePortals.Add(portal.Key, portal.Value);
                }
                else
                {
                    if (player.RangePortals.ContainsKey(portal.Key))
                    {
                        player.RangePortals.Remove(portal.Key);
                    }
                }
            }
            PortalsRangeStatus();
        }

        private void PortalsRangeStatus()
        {
            var player = (Player)Character;
            if (player.RangePortals.Count <= 0)
            {
                if (player.InEquipmentArea)
                    return;
                player.InDemiZone = false;
                player.InPortalArea = false;
                return;
            }
            player.InPortalArea = true;
            player.InDemiZone = true;
        }

        private void RangeStations()
        {
            var player = (Player)Character;
            foreach (var station in Character.Spacemap.Stations)
            {
                if (Vector.IsInRange(station.Position, player.Position, 1000) && station.Faction == player.FactionId)
                {
                    player.InDemiZone = true;
                    player.InEquipmentArea = true;
                    player.InTradeArea = true;
                    ReloadConfigs();
                }
                else
                {
                    if (player.RangePortals.Count > 0)
                    {
                        player.InTradeArea = false;
                        return;
                    }
                    player.InTradeArea = false;
                    player.InDemiZone = false;
                    player.InEquipmentArea = false;
                    return;
                }
            }
        }

        private DateTime LastReloadedTime = new DateTime(2016, 1, 1, 0, 0, 0);
        public void ReloadConfigs()
        {
            try
            {
                var dateTime = DateTime.Now;
                if (LastReloadedTime <= dateTime.AddSeconds(3) && !World.DatabaseManager.QueryRunning)
                {
                    var player = (Player)Character;
                    var configs = World.DatabaseManager.LoadConfig(player);
                    var hangar = World.DatabaseManager.LoadHangar(player);
                    var drones = World.DatabaseManager.LoadDrones(player);

                    player.Hangar = hangar;
                    player.Hangar.Configurations = configs;
                    player.Hangar.Drones = drones;

                    LastReloadedTime = DateTime.Now;
                }
            }
            catch (Exception)
            {
                Console.WriteLine("ERROR: Can't reload the confis.");
            }
        }

        public async void Jump(int targetMap, Vector targetPos)
        {
            var player = (Player) Character;
            if (Jumping)
                return;

            Jumping = true;
            for (int i = 0; i < 3; i++)
            {
                if (Dead || StopController || !Jumping)
                {
                    Jumping = false;
                    return;
                }

                await Task.Delay(1000);
            }

            Character.Position = targetPos;
            Character.Spacemap = World.StorageManager.Spacemaps[targetMap];

            player.BasicSave();

            Deselect(Character);
            Jumping = false;
            World.StorageManager.GetGameSession(Character.Id).Disconnect();
        }

        public void BeaconUpdate()
        {
            var player = (Player)Character;

            World.StorageManager.GetGameSession(player.Id)
                    .Client.Send(PacketBuilder.LegacyModule("0|" + ServerCommands.BEACON + "|0|0|" + Convert.ToInt32(player.InDemiZone) + "|" + Convert.ToInt32(Repairing) + "|" + Convert.ToInt32(player.InTradeArea) +
                    "|" + Convert.ToInt32(player.InRadiationArea) + "|" + Convert.ToInt32(player.InPortalArea) + "|0"));

            World.StorageManager.GetGameSession(player.Id).Client.Send(EquipReadyCommand.write(player.InEquipmentArea));
        }

    }
}
