﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Game.objects.world.map
{
    class Station
    {
        public Faction Faction { get; }
        public Vector Position { get; set; }

        public Station(Faction faction, Vector position)
        {
            Faction = faction;
            Position = position;
        }

        public string GetType()
        {
            switch (Faction)
            {
                case Faction.MMO:
                    return "redStation";
                case Faction.EIC:
                    return "blueStation";
                case Faction.VRU:
                    return "greenStation";
                default:
                    return "";
            }
        }

        public string GetString()
        {
            return "0|s|0|1|" + GetType() + "|" + (int)Faction + "|1500|" + Position.X + "|" + Position.Y;
        }
    }
}
