﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty.commands;

namespace NettyBaseReloaded.Game.objects.world.map
{
    class Asset
    {
        public int Id { get; set; }
        public short Type { get; set; }
        public string Name { get; set; }
        public int FactionId { get; set; }
        public string ClanTag { get; set; }
        public int AssetId { get; set; }
        public int DesignId { get; set; }
        public int ExpansionStage { get; set; }
        public Vector Position { get; set; }
        public int ClanId { get; set; }
        public bool Invisible { get; set; }
        public bool VisibleOnWarnRadar { get; set; }
        public bool DetectedByWarnRadar { get; set; }
        public ClanRelationModule ClanRelation { get; set; }
        public List<VisualModifierCommand> Modifiers { get; set; }

        public Asset(int id, string name, short type, int factionId, string clanTag, int assetId, int designId, int expansionStage, Vector position, int clanId, bool invisible,
            bool visibleOnWarnRadar, bool detectedByWarnRadar, ClanRelationModule clanRelation, List<VisualModifierCommand> modifiers)
        {
            Id = id;
            Type = type;
            Name = name;
            FactionId = factionId;
            ClanTag = clanTag;
            AssetId = assetId;
            DesignId = designId;
            ExpansionStage = expansionStage;
            Position = position;
            ClanId = clanId;
            Invisible = invisible;
            VisibleOnWarnRadar = visibleOnWarnRadar;
            DetectedByWarnRadar = detectedByWarnRadar;
            ClanRelation = clanRelation;
            Modifiers = modifiers;
        }
    }
}
