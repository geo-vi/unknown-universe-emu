﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Game.objects.world.map
{
    class PortalBase
    {
        public int Id { get; set; }
        public int x { get; set; }
        public int y { get; set; }
        public int newX { get; set; }
        public int newY { get; set; }
        public int Map { get; set; }

        public PortalBase(int Id, int x, int y, int newX, int newY, int Map)
        {
            this.Id = Id;
            this.x = x;
            this.y = y;
            this.newX = newX;
            this.newY = newY;
            this.Map = Map;
        }
    }

    class Jumpgate
    {
        public int Id { get; set; }

        public int LevelRequired { get; set; }

        public Vector Position { get; set; }

        public Vector Destination { get; set; }

        public int DestinationMapId { get; set; }

        public bool Visible { get; set; }
        
        public int FactionScrap { get; set; }
        
        public int RequiredLevel { get; set; }

        public int Gfx { get; set; }

        public Jumpgate(int id, Vector pos, Vector destinationPos, int destinationMapId, bool visible, int factionScrap, int requiredLevel, int gfx)
        {
            Id = id;
            Position = pos;
            Destination = destinationPos;
            DestinationMapId = destinationMapId;
            Visible = visible;
            FactionScrap = factionScrap;
            RequiredLevel = requiredLevel;
            Gfx = gfx;
        }

        public override string ToString()
        {
            return "0|p|" + Id + "|1|" + Gfx + "|" + Position.X + "|" + Position.Y + "|" + Convert.ToInt32(Visible) + "|" + FactionScrap;
        }
    }
}
