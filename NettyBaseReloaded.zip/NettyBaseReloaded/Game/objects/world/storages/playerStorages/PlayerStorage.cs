﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Game.objects.world.storages.playerStorages
{
    class PlayerStorage
    {
        public int Id { get; set; }

        public double EarnedCredits { get; set; }
        public double EarnedUridium { get; set; }
        public PlayerStorage(int id, int earnedCre, int earnedUri)
        {
            Id = id;

            EarnedCredits = earnedCre;
            EarnedUridium = earnedUri;
        }
    }
}
