﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty.commands;
using NettyBaseReloaded.Game.objects.world.map;
using NettyBaseReloaded.Game.controllers;
using NettyBaseReloaded.Game.netty;
using NettyBaseReloaded.Game.objects.world.players;
using NettyBaseReloaded.Main.interfaces;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Game.objects.world
{
    class Character : ITick
    {
        /**********
         * BASICS *
         **********/

        public int Id { get; }
        public string Name { get; set; }
        public Hangar Hangar { get; set; }
        public Faction FactionId { get; set; }
        public Reward Reward { get; }
        public DropableRewards DropableRewards { get; }

        public virtual AbstractCharacterController Controller
        {
            get
            {
                if (this is Player)
                {
                    var temp = (Player) this;
                    return temp.Controller;
                }
                if (this is Npc)
                {
                    var temp = (Npc) this;
                    return temp.Controller;
                }

                return null;
            }
        }

        /************
         * POSITION *
         ************/
        public Vector Position { get; set; }
        public Spacemap Spacemap { get; set; }

        /*********
         * STATS *
         *********/
        public virtual int MaxHealth { get; set; }

        private int _currentHealth;

        public int CurrentHealth
        {
            get { return _currentHealth; }
            set
            {
                _currentHealth = (value < MaxHealth) ? value : MaxHealth;
                if (value < 0) _currentHealth = 0;
            }
        }

        public virtual int MaxShield { get; set; }
        public virtual int CurrentShield { get; set; }
        public virtual double ShieldAbsorption { get; set; }
        public virtual double ShieldPenetration { get; set; }

        //The max amount of nanohull will be the maxHealth
        public int MaxNanoHull => MaxHealth;

        private int _currentNanoHull;

        public int CurrentNanoHull
        {
            get { return _currentNanoHull; }
            set
            {
                _currentNanoHull = (value < MaxNanoHull) ? value : MaxNanoHull;
                if (value < 0) _currentNanoHull = 0;
            }
        }

        public virtual int Speed => Hangar.Ship.Speed;

        public virtual int Damage { get; set; }
        public virtual int RocketDamage { get; set; }

        /************
         * MOVEMENT *
         ************/
        public bool Moving { get; set; }
        public Vector OldPosition { get; set; }
        public Vector Destination { get; set; }
        public Vector Direction { get; set; }
        public DateTime MovementStartTime { get; set; }
        public int MovementTime { get; set; }

        /*********
         * EXTRA *
         *********/
        public int RenderRange { get; set; }
        public Character Selected { get; set; }
        public Dictionary<int, Character> RangeEntities;
        public Dictionary<string, Collectable> RangeCollectables;
        public DateTime LastCombatTime;
        public DroneFormation Formation { get; set; }
        public bool Warping { get; set; }
        public List<VisualModifierCommand> VisualModifier { get; set; }

        protected Character(int id, string name, Hangar hangar, Faction factionId, Vector position, Spacemap spacemap,
            int currentHealth, int currentNanoHull, Reward rewards, DropableRewards dropableRewards,
            List<VisualModifierCommand> visualModifier = null)
        {
            Id = id;
            Name = name;
            Hangar = hangar;
            FactionId = factionId;
            Position = position;
            Spacemap = spacemap;
            CurrentHealth = currentHealth;
            CurrentNanoHull = currentNanoHull;
            Reward = rewards;
            DropableRewards = dropableRewards;

            //Default initialization
            Moving = false;
            OldPosition = new Vector(0, 0);
            Destination = position;
            Direction = new Vector(0, 0);
            MovementStartTime = new DateTime();
            MovementTime = 0;
            RenderRange = 2000;
            RangeEntities = new Dictionary<int, Character>();
            RangeCollectables = new Dictionary<string, Collectable>();
            LastCombatTime = DateTime.Now;
            Formation = DroneFormation.STANDARD;
            Warping = false;

            if (VisualModifier == null)
                VisualModifier = new List<VisualModifierCommand>();
            else
                VisualModifier = visualModifier;
        }

        public void Tick()
        {
            if (this is Npc)
            {
                ((Npc) this).Tick();
            }
            else if (this is Player)
            {
                ((Player) this).Tick();
            }
            //else if (this is Pet)
            //{

            //}

            Update();
            Regenerate();
        }

        public void Update()
        {
            try
            {
                if (CurrentHealth > MaxHealth) CurrentHealth = MaxHealth;
                if (CurrentHealth < 0) CurrentHealth = 0;
                if (CurrentShield > MaxShield) CurrentShield = MaxShield;
                if (CurrentShield < 0) CurrentShield = 0;


                if (this is Player)
                {
                    var player = (Player) this;
                    var gameSession = World.StorageManager.GetGameSession(Id);
                    if (gameSession == null) return;
                    var gameHandler = gameSession.Client;

                    gameHandler.Send(AttributeHitpointUpdateCommand.write(player.CurrentHealth, player.MaxHealth));
                    //Update shield
                    gameHandler.Send(AttributeShieldUpdateCommand.write(player.CurrentShield, player.MaxShield));
                    //Update speed
                    gameHandler.Send(PacketBuilder.SpeedUpdateCommand(player.Speed));
                }

                //Update shield for other players
                GameClient.SendPacketSelected(this, PacketBuilder.ShipSelectionCommand(this));
            }
            catch (Exception)
            {
            }

        }

        private DateTime LastRegeneratedTime = new DateTime(2016, 12, 24, 0, 0,0);
        private void Regenerate()
        {
            try
            {
                if (LastCombatTime.AddSeconds(5) >= DateTime.Now || Controller.Attacked || CurrentShield >= MaxShield || LastRegeneratedTime.AddSeconds(1) >= DateTime.Now) return;

                if (LastCombatTime.AddSeconds(5) <= DateTime.Now)
                {
                    // Takes 25 secs to recover the shield
                    var amount = MaxShield/25;
                    //If the amount + currentShield is more than the maxShield adjusts it
                    if ((CurrentShield + amount) > MaxShield)
                        amount = MaxShield - CurrentShield;

                    CurrentShield += amount;

                    //Shield update
                    if (this is Player)
                        World.StorageManager.GetGameSession(Id)
                            .Client.Send(PacketBuilder.ShieldUpdateCommand(CurrentShield,
                                MaxShield));
                    //Updates the shield for the users who have 'you' clicked
                    GameClient.SendPacketSelected(this, PacketBuilder.ShipSelectionCommand(this));

                    LastRegeneratedTime = DateTime.Now;
                }
            }
            catch (Exception)
            {
                
            }
        }

        public bool InRange(Character character, int range = 2000)
        {
            //return true;
            if (character == null) return false;
            if (range == -1) return true;

            return character.Id != Id && character.Spacemap.Id == Spacemap.Id && Position.DistanceTo(character.Position) <= range;
        }
    }
}
