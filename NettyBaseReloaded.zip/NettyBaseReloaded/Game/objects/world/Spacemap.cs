﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.controllers;
using NettyBaseReloaded.Game.objects.world.map;
using NettyBaseReloaded.Game.objects.world.players;
using NettyBaseReloaded.Main.interfaces;

namespace NettyBaseReloaded.Game.objects.world
{
    class Spacemap : ITick
    {
        /**********
         * BASICS *
         **********/
        public int Id { get; }
        public string Name { get; }
        public Faction Faction { get; }
        public bool Pvp { get; }
        public bool Starter { get; }
        public string MapLimits { get; }

        public List<PortalBase> PortalBase { get; set; }
        public Dictionary<int, Jumpgate> Portals;

        // Used to store all the NPCs on the current map. (type, Npc)
        public List<BaseNpc> Npcs;

        // Used to store all the collectables on the current map. (hash, Collectable)
        //private Dictionary<int, BaseCollectable> BaseCollectable;
        //public Dictionary<string, Collectable> Collectables;
        public List<string> HoneyBoxes;

        //Used to store all the entities of the map
        public Dictionary<int, Character> Entities;

        public Dictionary<int, Asset> Assets;

        public List<Station> Stations;

        //TODO add stations
        public Spacemap(int id, string name, Faction faction, bool pvp, bool starter, List<BaseNpc> npcs, /*Dictionary<int, BaseCollectable> collectables*/ List<PortalBase> portals)
        {
            Id = id;
            Name = name;
            Faction = faction;
            Pvp = pvp;
            Starter = starter;
            MapLimits = "208x128";
            PortalBase = portals;
            Npcs = npcs;
            //BaseCollectable = collectables;
            //Collectables = new Dictionary<string, Collectable>();
            HoneyBoxes = new List<string>();
            Stations = new List<Station>();
            Entities = new Dictionary<int, Character>();
            Portals = new Dictionary<int, Jumpgate>();
            Assets = new Dictionary<int, Asset>();

            //World.TickManager.Tickables.Add(this);
        }

        public void Tick()
        {
            // TODO: Add tickables
        }

        public void SpawnNpcs(bool displayNpcCount = false)
        {
            if (Npcs == null || Npcs.Count <= 0)
                return;

            int npcSpawned = 0;
            foreach (var npc in Npcs)
            {
                if (npc.Count > 0)
                {
                    for (int i = 0; i < npc.Count; i++)
                    {
                        npcSpawned++;
                        CreateNpc(npc);
                    }
                }
            }

            if (displayNpcCount) Out.WriteLine("Successfully spawned " + npcSpawned + " npcs on spacemap " + Name);
        }

        public void ListPortals()
        {
            if (PortalBase == null)
                return;

            foreach (var portal in PortalBase)
            {
                CreatePortal(portal.Id, portal.Map, portal.x, portal.y, portal.newX, portal.newY);
            }
        }

        public void CreatePortal(int id, int map, int x, int y, int newX, int newY)
        {
            Portals.Add(id, new Jumpgate(id, new Vector(x, y), new Vector(newX, newY), map, true, 0, 0, 1));
        }


        private int GetNextNPCId()
        {
            int i = 0;
            foreach (var entity in Entities)
            {
                if (entity.Value is Npc)
                {
                    i++;
                }
            }
            return i;
        }

        public void CreateShipLoot(Vector position, DropableRewards content)
        {
            //var hash = "";
            //hash = Random.String(5);
            //while (Collectables.ContainsKey(hash))
            //{
            //    hash = Random.String(5);
            //}

            //Collectables.Add(hash, new Collectable(hash, 38, position, content));
        }

        public void CreateNpc(BaseNpc baseNpc)
        {
            var id = GetNextNPCId();
            var ship = World.StorageManager.Ships[baseNpc.NpcId];
            var position = Vector.Random(1000, 20000, 1000, 12000);

            var npc = new Npc(id, ship.Name, new Hangar(ship, new List<Drone>(), position, this, ship.Health, ship.Nanohull, new Dictionary<string, Item>()),
                0, position, this, ship.Health, ship.Nanohull, ship.Reward, ship.DropableRewards, ship.Shield, ship.Damage);

            if (Entities.ContainsKey(npc.Id))
                return;

            Entities.Add(npc.Id, npc);

            npc.Controller = new NpcController(npc, (AILevels)ship.AI);
            npc.Controller.Start();
        }
    }
}
