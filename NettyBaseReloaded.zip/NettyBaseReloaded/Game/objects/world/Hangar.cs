﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.objects.world.players;

namespace NettyBaseReloaded.Game.objects.world
{
    class Hangar
    {
        public Ship Ship { get; set; }
        public List<Drone> Drones { get; set; }
        public Configuration[] Configurations { get; set; }

        public Vector Position { get; set; }

        public Spacemap Spacemap { get; set; }

        public int Health { get; set; }

        public int Nanohull { get; set; }

        public Dictionary<string, Item> Consumables { get; set; }

        public bool Active = false;

        //Configurations can be null because npcs will use this class too
        public Hangar(Ship ship, List<Drone> drones, Vector position, Spacemap spacemap, int hp, int nano, Dictionary<string, Item> consumables, bool active = true, Configuration[] configurations = null)
        {
            Ship = ship;
            Drones = drones;
            Position = position;
            Spacemap = spacemap;
            Health = hp;
            Nanohull = nano;
            Consumables = consumables;
            Active = active;
            Configurations = configurations;
        }
    }
}
