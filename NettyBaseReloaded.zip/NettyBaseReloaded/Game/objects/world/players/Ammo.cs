﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty.commands;

namespace NettyBaseReloaded.Game.objects.world.players
{
    class Ammo
    {
        public int LCB_10 { get; set; }
        public int MCB_25 { get; set; }
        public int MCB_50 { get; set; }
        public int SAB_50 { get; set; }
        public int UCB_100 { get; set; }
        public int CBO_100 { get; set; }
        public int RSB_75 { get; set; }
        public int JOB_100 { get; set; }

        public int R_310 { get; set; }
        public int PLT2021 { get; set; }
        public int PLT2026 { get; set; }
        public int PLT3030 { get; set; }

        public int ECO_10 { get; set; }

        public int EMP_01 { get; set; }

        public Ammo(int lcb, int mcb25, int mcb50, int sab50, int ucb100, int cbo100, int rsb75, int job100, int r310, int plt2021,
            int plt2026, int plt3030, int eco10, int emp)
        {
            LCB_10 = lcb;
            MCB_25 = mcb25;
            MCB_50 = mcb50;
            SAB_50 = sab50;
            UCB_100 = ucb100;
            CBO_100 = cbo100;
            RSB_75 = rsb75;
            JOB_100 = job100;

            R_310 = r310;
            PLT2021 = plt2021;
            PLT2026 = plt2026;
            PLT3030 = plt3030;

            ECO_10 = eco10;

            EMP_01 = emp;
        }

        public byte[] GetPacket()
        {
            var ammoList = new List<AmmunitionCountModule>();
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.X1), LCB_10));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.X2), MCB_25));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.X3), MCB_50));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.X4), UCB_100));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.SAB), SAB_50));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.CBO), CBO_100));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.RSB), RSB_75));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.JOB100), JOB_100));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.EMP), EMP_01));
            //ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.MINE), 0));
            //ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.INSTANT_SHIELD), 0));
            //ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.SMARTBOMB), 0));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.R310), R_310));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.PLT2021), PLT2021));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.PLT2026), PLT2026));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.PLT3030), PLT3030));
            ammoList.Add(new AmmunitionCountModule(new AmmunitionTypeModule(AmmunitionTypeModule.ECO_ROCKET), ECO_10));
            return AmmunitionCountUpdateCommand.write(ammoList);
        }

        public string toSqlString(bool normal = true)
        {
            if (normal)
                return " " + "LCB_10=" + LCB_10 + ", " + "MCB_25=" + MCB_25 + ", " + "MCB_50=" + MCB_50 + ", " + "UCB_100=" + UCB_100 + ", " + "SAB_50=" + SAB_50 +
                    ", " + "CBO_100=" + CBO_100 + ", " + "RSB_75=" + RSB_75 + ", " + "JOB_100=" + JOB_100 + ", " + "R_310=" + R_310 + ", " + "PLT_2021=" + PLT2021 +
                    ", " + "PLT_2026=" + PLT2026 + ", PLT_3030=" + PLT3030 + ", " + "ECO_10=" + ECO_10 + ", " + "EMP_01=" + EMP_01 + " ";
            return " " + "player_ammo.LCB_10=" + LCB_10 + ", " + "player_ammo.MCB_25=" + MCB_25 + ", " + "player_ammo.MCB_50=" + MCB_50 + ", " + "player_ammo.UCB_100=" + UCB_100 + ", " + "player_ammo.SAB_50=" + SAB_50 +
                 ", " + "player_ammo.CBO_100=" + CBO_100 + ", " + "player_ammo.RSB_75=" + RSB_75 + ", " + "player_ammo.JOB_100=" + JOB_100 + ", " + "player_ammo.R_310=" + R_310 + ", " + "player_ammo.PLT_2021=" + PLT2021 +
                 ", " + "player_ammo.PLT_2026=" + PLT2026 + ", " + "player_ammo.PLT_3030=" + PLT3030 + ", " + "player_ammo.ECO_10=" + ECO_10 + ", " + "player_ammo.EMP_01=" + EMP_01 + " ";
        }

        public void Add(short ammunitionType, int amount)
        {
            switch (ammunitionType)
            {
                case AmmunitionTypeModule.X1:
                    LCB_10 += amount;
                    break;
                case AmmunitionTypeModule.X2:
                    MCB_25 += amount;
                    break;
                case AmmunitionTypeModule.X3:
                    MCB_50 += amount;
                    break;
                case AmmunitionTypeModule.X4:
                    UCB_100 += amount;
                    break;
                case AmmunitionTypeModule.SAB:
                    SAB_50 += amount;
                    break;
                case AmmunitionTypeModule.CBO:
                    CBO_100 += amount;
                    break;
                case AmmunitionTypeModule.RSB:
                    RSB_75 += amount;
                    break;
                case AmmunitionTypeModule.JOB100:
                    JOB_100 += amount;
                    break;
            }
        }
    }
}
