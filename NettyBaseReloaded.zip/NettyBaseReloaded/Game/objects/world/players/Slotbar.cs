﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Game.objects.world.players
{
    class Slotbar
    {
        public string QuickbarSlots { get; set; }
        public string QuickbarSlotsPremium { get; set; }

        public int SelectedLaser { get; set; }
        public int SelectedRocket { get; set; }
        public int SelectedHellstormRocket { get; set; }

        public Slotbar(string quickbarSlots, string quickbarSlotsPremium, int selectedLaser,
            int selectedRocket, int selectedHellstormRocket)
        {
            QuickbarSlots = quickbarSlots;
            QuickbarSlotsPremium = quickbarSlotsPremium;

            SelectedLaser = selectedLaser;
            SelectedRocket = selectedRocket;
            SelectedHellstormRocket = selectedHellstormRocket;
        }
    }
}
