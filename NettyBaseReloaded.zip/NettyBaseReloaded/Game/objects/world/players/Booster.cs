﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Game.objects.world.players
{
    class Booster
    {
        public int Type { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime ExpireTime { get; set; }

        public Booster(int type, DateTime startTime, DateTime expireTime)
        {
            Type = type;
            StartTime = startTime;
            ExpireTime = expireTime;
        }

        public int GetTimeInMins()
        {
            return (ExpireTime = StartTime).Minute;
        }
    }
}
