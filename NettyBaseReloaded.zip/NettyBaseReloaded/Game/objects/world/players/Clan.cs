﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NettyBaseReloaded.Game.objects.world.players
{
    class Clan
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Tag { get; set; }

        // TODO: Add owned BattleStations

        public Clan(int id, string name, string tag)
        {
            Id = id;
            Name = name;
            Tag = tag;
        }
    }
}
