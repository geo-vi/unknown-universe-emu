﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty.commands;
using Newtonsoft.Json;

namespace NettyBaseReloaded.Game.objects.world.players
{
    class Settings
    {
        public QualitySettingsModule QualitySettingsModule { get; set; }
        public DisplaySettingsModule DisplaySettingsModule { get; set; }
        public AudioSettingsModule AudioSettingsModule { get; set; }
        public WindowSettingsModule WindowSettingsModule { get; set; }
        public GameplaySettingsModule GameplaySettingsModule { get; set; }

        public Slotbar Slotbar { get; set; }

        public Settings(QualitySettingsModule qualitySettingsModule, DisplaySettingsModule displaySettingsModule, AudioSettingsModule audioSettingsModule,
            WindowSettingsModule windowSettingsModule, GameplaySettingsModule gameplaySettingsModule, Slotbar slotbar)
        {
            QualitySettingsModule = qualitySettingsModule;
            DisplaySettingsModule = displaySettingsModule;
            AudioSettingsModule = audioSettingsModule;
            WindowSettingsModule = windowSettingsModule;
            GameplaySettingsModule = gameplaySettingsModule;
            Slotbar = slotbar;
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
