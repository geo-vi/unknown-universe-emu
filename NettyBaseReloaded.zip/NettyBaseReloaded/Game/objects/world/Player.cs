﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.controllers;
using NettyBaseReloaded.Game.netty.commands;
using NettyBaseReloaded.Game.objects.world.map;
using NettyBaseReloaded.Game.objects.world.players;
using NettyBaseReloaded.Game.objects.world.storages.playerStorages;

namespace NettyBaseReloaded.Game.objects.world
{
    class Player : Character
    {
        /**********
         * BASICS *
         **********/
        public string SessionId { get; set; }
        public Rank RankId { get; set; }
        public new PlayerController Controller { get; set; }

        /***************
         * INFORMATION *
         ***************/
        public Clan Clan { get; set; }
        public Group Group { get; set; }
        public Level Level { get; set; }
        public long Experience { get; set; }
        public long Honor { get; set; }
        public double Credits { get; set; }
        public double Uridium { get; set; }
        public int GGSpins { get; set; }
        public float Jackpot { get; set; }

        public int[] BootyKeys { get; set; }

        /*********
         * EXTRA *
         *********/
        private int _rings;
        public int Rings
        {
            get { return _rings; }
            //64 => Kronos (Max value)
            set { _rings = (value <= 64) ? value : 64; }
        }

        public bool Premium { get; set; }
        public int CurrentConfig { get; set; }

        public Dictionary<int, Item> Consumables { get; set; }
        public Ammo CurrentAmmo { get; set; }
        public Ammo SpentAmmo { get; set; }

        public bool SoftBan { get; set; }
        public bool InEquipmentArea { get; set; }
        public bool InTradeArea { get; set; }
        public bool InDemiZone { get; set; }
        public bool InRadiationArea { get; set; }
        public bool InPortalArea { get; set; }
        public int JumpVouchers { get; set; }

        public Pet Pet { get; set; }

        public List<Booster> Boosters { get; set; }

        public Settings Settings { get; set; }

        public RocketLauncher RocketLauncher { get; set; }

        public StatsStorage Stats { get; set; }

        public PlayerStorage UserStorage { get; set; }
        //public StatsStorage QuestStats { get; set; }

        /*********
         * STATS *
         *********/
        public override int MaxHealth
        {
            get
            {
                var value = Hangar.Ship.Health;

                switch (Formation)
                {
                    case DroneFormation.DIAMOND:
                        value = (int)(value * 0.7); //-30%
                        break;
                }

                return value;
            }
        }

        public override int MaxShield
        {
            get
            {
                var value = Hangar.Configurations[CurrentConfig - 1].MaxShield;

                switch (Formation)
                {
                    case DroneFormation.RING:
                        value = (int)(value * 2.2); //+120%
                        break;
                    case DroneFormation.DRILL:
                        value = (int)(value * 0.75); //-25%
                        break;
                    case DroneFormation.TURTLE:
                        value = (int)(value * 1.1); //+10%
                        break;
                    case DroneFormation.DOUBLE_ARROW:
                        value = (int)(value * 0.8); //-20%
                        break;

                }

                return value;
            }
        }

        public override int CurrentShield
        {
            get { return Hangar.Configurations[CurrentConfig - 1].CurrentShield; }
            set { Hangar.Configurations[CurrentConfig - 1].CurrentShield = value; }
        }

        public override double ShieldAbsorption
        {
            get
            {
                var value = Hangar.Configurations[CurrentConfig - 1].ShieldAbsorbation;
                switch (Formation)
                {
                    case DroneFormation.CRAB:
                        value += 0.2;
                        break;

                }

                return value;
            }
        }

        public override double ShieldPenetration
        {
            get
            {
                switch (Formation)
                {
                    case DroneFormation.MOTH:
                        return 0.2;
                    case DroneFormation.PINCER:
                        return -0.1;
                    case DroneFormation.DOUBLE_ARROW:
                        return 0.1;
                    default:
                        return 0;
                }
            }
        }

        public override int Speed
        {
            get
            {
                return Hangar.Ship.Speed + Hangar.Configurations[CurrentConfig - 1].Speed;

            }
        }

        public override int Damage
        {
            get
            {
                var value = Hangar.Configurations[CurrentConfig - 1].Damage;
                switch (Formation)
                {
                    case DroneFormation.TURTLE:
                        value = (int)(value * 0.925); //-7.5%
                        break;
                    case DroneFormation.ARROW:
                        value = (int)(value * 0.97); //-3%
                        break;
                    case DroneFormation.PINCER:
                        value = (int)(value * 1.03); //+3%
                        break;

                }

                return value;
            }
        }

        public override int RocketDamage
        {
            get
            {
                var value = 1000;
                switch (Formation)
                {
                    case DroneFormation.TURTLE:
                        value = (int)(value * 0.925); //-7.5%
                        break;
                    case DroneFormation.ARROW:
                        value = (int)(value * 1.2); //+20%
                        break;
                    case DroneFormation.STAR:
                        value = (int)(value * 1.25); //+25%
                        break;

                }

                return value;
            }
        }

        public List<Drone> Drones => Hangar.Drones;

        public Dictionary<int, Ability> Abilities { get; set; }

        public Dictionary<int, Jumpgate> RangePortals;
        public Dictionary<int, Asset> RangeAssets;

        public List<InvitedForGroup> InvitedForGroups { get; set; }

        public Cargo Cargo;

        public Player(int id, string name, string sessionId, Hangar hangar, Clan clan, Faction factionId, Reward rewards, DropableRewards dropableRewards,
            Rank rankId, Level level, long experience, long honor, double credits, double uridium, float jackpot, int rings, bool premium, RocketLauncher launcher, Cargo cargo, StatsStorage stats, Settings settings, Dictionary<int, Item> consumables)
            : base(id, name, hangar, factionId, hangar.Position, hangar.Spacemap, hangar.Health, hangar.Nanohull, rewards, dropableRewards)
        {
            SessionId = sessionId;
            RankId = rankId;
            Level = level;
            Experience = experience;
            Honor = honor;
            Credits = credits;
            Uridium = uridium;
            Jackpot = jackpot;
            Rings = rings;
            Premium = premium;
            CurrentConfig = 1; //Selected config1 by default
            Clan = clan;
            Consumables = consumables;
            RocketLauncher = launcher;
            Cargo = cargo;
            Stats = stats;
            Settings = settings;

            SoftBan = false;

            RangePortals = new Dictionary<int, Jumpgate>();
            RangeAssets = new Dictionary<int, Asset>();

            InDemiZone = false;
            InRadiationArea = false;
            InTradeArea = false;
            InEquipmentArea = false;
            InPortalArea = false;

            SpentAmmo = new Ammo(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            UserStorage = new PlayerStorage(Id, 0, 0);

            Boosters = new List<Booster>();
            BootyKeys = new[] { 2, 2, 1 };
            Abilities = new Dictionary<int, Ability>();
            Pet = null;
            Group = null;
            InvitedForGroups = new List<InvitedForGroup>();
            JsonChecker();
        }

        public void Tick()
        {
            BasicSave();
        }

        public DateTime LastSaveTime = new DateTime(2016, 12, 24, 0, 0,0);
        public void BasicSave()
        {
            if (LastSaveTime.AddMinutes(1) > DateTime.Now || World.DatabaseManager.QueryRunning) return;

            World.DatabaseManager.BasicSave(this);
            LastSaveTime = DateTime.Now;
        }

        public void InstantSave()
        {
            if (World.DatabaseManager.QueryRunning) return;

            World.DatabaseManager.BasicSave(this);
            LastSaveTime = DateTime.Now;
        }

        private void JsonChecker()
        {
            if (Stats == null) Stats = new StatsStorage(Id, new Dictionary<int, int>(), new Dictionary<int, int>());
            if (Cargo == null) Cargo = new Cargo(Id, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            if (Settings == null) Settings = new Settings(
                new QualitySettingsModule(false, 3, 3, 3, true, 3, 3, 3, 3, 3, 3),
                new DisplaySettingsModule(false, true, true, true, true, true, false, true, true, true, true, true, true,
                    true, true, true),
                new AudioSettingsModule(false, false, false),
                new WindowSettingsModule(false, 1,
                    "0,444,-1,0,1,1057,329,1,20,39,530,0,3,1021,528,1,5,-10,-6,0,24,463,15,0,10,101,307,0,36,100,400,0,13,315,122,0,23,1067,132,0",
                    "5,240,150,20,300,150,36,260,175,", 11, "313,480", "23,0,24,0,25,1,26,0,27,0", "313,451", "0",
                    "313,500", "0"),
                new GameplaySettingsModule(false, true, true, true, true, true, true, true),
                new Slotbar("", "", AmmunitionTypeModule.X1, AmmunitionTypeModule.R310, AmmunitionTypeModule.ECO_ROCKET));

            if (Stats.KilledShipsDictionary == null)
                Stats.KilledShipsDictionary = new Dictionary<int, int>();
            if (Stats.CollectedBoxesDictionary == null)
                Stats.CollectedBoxesDictionary = new Dictionary<int, int>();

            if (Settings.QualitySettingsModule == null)
                Settings.QualitySettingsModule = new QualitySettingsModule(false, 3, 3, 3, true, 3, 3, 3, 3, 3, 3);
            if (Settings.DisplaySettingsModule == null)
                Settings.DisplaySettingsModule = new DisplaySettingsModule(false, true, true, true, true, true, false, true, true, true, true, true, true,
                    true, true, true);
            if (Settings.AudioSettingsModule == null)
                Settings.AudioSettingsModule = new AudioSettingsModule(false, false, false);
            if (Settings.WindowSettingsModule == null)
                Settings.WindowSettingsModule = new WindowSettingsModule(false, 1,
                    "0,444,-1,0,1,1057,329,1,20,39,530,0,3,1021,528,1,5,-10,-6,0,24,463,15,0,10,101,307,0,36,100,400,0,13,315,122,0,23,1067,132,0",
                    "5,240,150,20,300,150,36,260,175,", 11, "313,480", "23,0,24,0,25,1,26,0,27,0", "313,451", "0",
                    "313,500", "0");
            if (Settings.GameplaySettingsModule == null)
                Settings.GameplaySettingsModule = new GameplaySettingsModule(false, true, true, true, true, true, true, true);
            if (Settings.Slotbar == null)
                Settings.Slotbar = new Slotbar("", "", AmmunitionTypeModule.X1, AmmunitionTypeModule.R310, AmmunitionTypeModule.ECO_ROCKET);

        }

        public string GetConsumablesPacket()
        {
            bool rep = true;
            bool droneRep = false;
            bool ammoBuy = false;
            bool cloak = false;
            bool tradeDrone = false;
            bool smb = false;
            bool ish = false;
            bool aim = false;
            bool autoRocket = false;
            bool autoRocketLauncer = false;
            bool rocketBuy = false;
            bool jump = false;
            bool petRefuel = false;
            bool jumpToBase = false;

            if (Consumables != null && Consumables.Count > 0)
            {
                foreach (var item in Consumables)
                {
                    if (item.Value.LootId == "cloakCPU" || item.Value.LootId == "cloakCPU2")
                    {
                        cloak = true;
                    }
                }
            }

            return Convert.ToInt32(droneRep) + "|0|" + Convert.ToInt32(jumpToBase) + "|" + Convert.ToInt32(ammoBuy) + "|" + Convert.ToInt32(rep) + "|" + Convert.ToInt32(tradeDrone) + "|0|" + Convert.ToInt32(smb) + "|" + Convert.ToInt32(ish) + "|0|" + Convert.ToInt32(aim) + "|" + Convert.ToInt32(autoRocket) + "|" + Convert.ToInt32(cloak) + "|" + Convert.ToInt32(autoRocketLauncer) + "|" + Convert.ToInt32(rocketBuy) + "|" + Convert.ToInt32(jump) + "|" + Convert.ToInt32(petRefuel);
        }

        public int LaserCount()
        {
            return Hangar.Configurations[CurrentConfig - 1].LaserCount;
        }
    }
}
