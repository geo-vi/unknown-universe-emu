﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.objects;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Game.objects.world.map;
using NettyBaseReloaded.Game.objects.world.players;

namespace NettyBaseReloaded.Game.managers
{
    class StorageManager
    {
        public Dictionary<int, GameSession> GameSessions = new Dictionary<int, GameSession>();
        public Dictionary<int, Player> Accounts = new Dictionary<int, Player>();
        public static Dictionary<int, Clan> Clans = new Dictionary<int, Clan>();
        public Dictionary<int, Ship> Ships = new Dictionary<int, Ship>();
        public Dictionary<int, Spacemap> Spacemaps = new Dictionary<int, Spacemap>();
        public List<Ore> OrePrices = new List<Ore>();
        public Levels Levels = new Levels();

        public GameSession GetGameSession(int userId)
        {
            return GameSessions.ContainsKey(userId) ? GameSessions[userId] : null;
        }
    }
}
