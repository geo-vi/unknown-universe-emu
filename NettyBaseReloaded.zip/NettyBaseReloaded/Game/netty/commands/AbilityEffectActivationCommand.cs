﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Game.netty.commands
{
    class AbilityEffectActivationCommand
    {
        public const short ID = 13678;
        public static byte[] write(int selectedAbilityId, int activatorId, List<int> targetIds)
        {
            var cmd = new ByteArray(ID);
            cmd.Integer(selectedAbilityId);
            cmd.Integer(activatorId);
            cmd.Integer(targetIds.Count);
            foreach (var target in targetIds)
            {
                cmd.Integer(target);
            }
            return cmd.ToByteArray();
        }
    }
}
