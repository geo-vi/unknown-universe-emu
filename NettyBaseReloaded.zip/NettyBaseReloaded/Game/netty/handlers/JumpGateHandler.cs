﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.objects;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Game.objects.world.map;

namespace NettyBaseReloaded.Game.netty.handlers
{
    class JumpGateHandler : ILegacyHandler
    {
        public void execute(GameSession gameSession, string[] param)
        {
            if (gameSession == null) return;

            var nearestPortal = getNearestPortal(gameSession);
            if (nearestPortal != null)
            {
                gameSession.Client.Send(PacketBuilder.LegacyModule("0|" + ServerCommands.PLAY_PORTAL_ANIMATION + "|" + nearestPortal.DestinationMapId
                    + "|" + nearestPortal.Id));
                gameSession.Player.Controller.Jump(nearestPortal.DestinationMapId, nearestPortal.Destination);
            }

        }

        private Jumpgate getNearestPortal(GameSession gameSession)
        {
            foreach (var portal in gameSession.Player.Spacemap.Portals)
            {
                if (Vector.IsInRange(gameSession.Player.Position, portal.Value.Position, 1000))
                {
                    return portal.Value;
                }
            }
            return null;
        }

    }
}
