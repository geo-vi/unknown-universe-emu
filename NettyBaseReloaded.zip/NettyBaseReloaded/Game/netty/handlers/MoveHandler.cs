﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.controllers;
using NettyBaseReloaded.Game.objects;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Utils;

namespace NettyBaseReloaded.Game.netty.handlers
{
    class MoveHandler : IHandler
    {
        public void execute(GameSession gameSession, ByteParser parser)
        {
            if (gameSession == null) return;

            int currentPosX = parser.Int();
            int targetPosY = parser.Int();
            int targetPosX = parser.Int();
            int currentPosY = parser.Int();

            var newVector = new Vector(targetPosX, targetPosY);    
            MovementController.Move(gameSession.Player, newVector);   
        }
    }
}
