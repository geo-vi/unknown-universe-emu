﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Game.netty.commands;
using NettyBaseReloaded.Game.objects.world;
using NettyBaseReloaded.Game.objects.world.map;

namespace NettyBaseReloaded.Game.netty
{
    static class PacketBuilder
    {
        public static byte[] ShipInitializationCommand(Player player)
        {
            return commands.ShipInitializationCommand.write(
                player.Id,
                player.Name,
                player.Hangar.Ship.Id,
                player.Speed,
                player.CurrentShield,
                player.MaxShield,
                player.CurrentHealth,
                player.MaxHealth,
                player.Cargo.Free(player.Hangar.Ship.Cargo), //freeCargo
                player.Hangar.Ship.Cargo, //maxCargo
                player.CurrentNanoHull,
                player.MaxNanoHull,
                player.Position.X,
                player.Position.Y,
                player.Spacemap.Id,
                (int)player.FactionId,
                player.Clan.Id,
                0,
                0,
                player.Hangar.Configurations[player.CurrentConfig].LaserCount,
                player.Premium,
                player.Experience,
                player.Honor,
                player.Level.Id,
                player.Credits,
                player.Uridium,
                player.Jackpot,
                (int)player.RankId,
                player.Clan.Tag, //clanTag
                player.Rings,
                true,
                false, //cloaked
                player.VisualModifier
                );
        }

        public static byte[] ShipCreateCommand(Character character)
        {
            if (character is Player)
            {
                var player = (Player)character;

                return commands.ShipCreateCommand.write(
                    player.Id,
                    player.Hangar.Ship.Id,
                    player.Hangar.Configurations[player.CurrentConfig].LaserCount,
                    player.Clan.Tag,
                    player.Name,
                    player.Position.X,
                    player.Position.Y,
                    (int)player.FactionId,
                    player.Clan.Id,
                    (int)player.RankId,
                    false, //warnIcon
                    new ClanRelationModule(ClanRelationModule.NONE),
                    player.Rings,
                    true,
                    false, //npc
                    false,//player.Controller.Invisible, //cloaked
                    0,
                    0, //idk
                    player.VisualModifier
                    );
            }
            return commands.ShipCreateCommand.write(
                character.Id,
                character.Hangar.Ship.Id,
                0, //idk
                "", //clanTag
                character.Name,
                character.Position.X,
                character.Position.Y,
                (int)character.FactionId,
                -1, //idk
                0, //rankId
                false, //warnIcon
                new ClanRelationModule(ClanRelationModule.NONE),
                0, //Rings
                true,
                true, //npc
                false,//character.Controller.Invisible, //cloaked
                0, //idk
                0,
                character.VisualModifier
                );
        }

        public static byte[] UserSettingsCommand()
        {
            return commands.UserSettingsCommand.write(
                new QualitySettingsModule(false, 3, 3, 3, true, 3, 3, 3, 3, 3, 3),
                new DisplaySettingsModule(false, true, true, true, true, true, false, true, true, true, true, true, true,
                    true, true, true),
                new AudioSettingsModule(false, false, false),
                new WindowSettingsModule(false, 1,
                    "0,444,-1,0,1,1057,329,1,20,39,530,0,3,1021,528,1,5,-10,-6,0,24,463,15,0,10,101,307,0,36,100,400,0,13,315,122,0,23,1067,132,0",
                    "5,240,150,20,300,150,36,260,175,", 11, "313,480", "23,0,24,0,25,1,26,0,27,0", "313,451", "0",
                    "313,500", "0"),
                new GameplaySettingsModule(false, true, true, true, true, true, true, true));
        }

        public static byte[] DronesCommand(Character character)
        {
            if (character.Hangar.Drones.Count <= 0) return LegacyModule("");

            var command = "0|n|d|" + character.Id + "|" + (int)character.Formation;

            foreach (var d in character.Hangar.Drones)
            {
                command += "|" + (int)d.DroneType + "|" + d.Level + "|0";
            }
            return LegacyModule(command);
        }

        public static byte[] BigMessage(string message)
        {
            return LegacyModule("0|n|MSG|1|1|" + message + "|[{w:%MESSAGE%,v: " + message + "}]");
        }

        public static byte[] LegacyModule(string message)
        {
            return commands.LegacyModule.write(message);
        }

        public static byte[] SpeedUpdateCommand(int newSpeed)
        {
            return AttributeShipSpeedUpdateCommand.write(newSpeed);
        }

        public static byte[] ShieldUpdateCommand(int shieldNow, int shieldMax)
        {
            return AttributeShieldUpdateCommand.write(shieldNow, shieldMax);
        }

        public static byte[] MoveCommand(int entityId, Vector destination, int time)
        {
            return commands.MoveCommand.write(
                entityId,
                destination.X,
                destination.Y,
                time
                );

        }

        public static byte[] ShipRemoveCommand(int userId)
        {
            return commands.ShipRemoveCommand.write(userId);
        }

        public static byte[] ShipSelectionCommand(Character character)
        {
            if (!(character is Player || character is Npc || character is Pet))
            {
                return commands.ShipSelectionCommand.write(
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                false
                );
            }
            return commands.ShipSelectionCommand.write(
                character.Id,
                character.Hangar.Ship.Id, //idk probably shipId for group
                character.CurrentShield,
                character.MaxShield,
                character.CurrentHealth,
                character.MaxHealth,
                character.CurrentNanoHull,
                character.MaxNanoHull,
                false //bubleshield
                );
        }

        public static byte[] ShipDeselectionCommand()
        {
            return commands.ShipDeselectionCommand.write();
        }

        public static byte[] CreateAsset(Asset asset)
        {
            return commands.AssetCreateCommand.write(new AssetTypeModule(asset.Type), asset.Name, asset.FactionId,
                asset.ClanTag, asset.Id, asset.DesignId,
                asset.ExpansionStage, asset.Position.X, asset.Position.Y, asset.ClanId, asset.Invisible, asset.VisibleOnWarnRadar,
                asset.DetectedByWarnRadar,
                asset.ClanRelation, asset.Modifiers);
        }
    }
}
