﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.managers;
using NettyBaseReloaded.Chat.netty;

namespace NettyBaseReloaded.Chat
{
    class Chat
    {
        public static StorageManager StorageManager = new StorageManager();
        public static DatabaseManager DatabaseManager = new DatabaseManager();

        public static void InitiateManagers()
        {
            PacketHandler.AddPackets();
            DatabaseManager.LoadAll();
        }
    }
}
