﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.netty;
using NettyBaseReloaded.Chat.objects;
using NettyBaseReloaded.Chat.objects.chat;

namespace NettyBaseReloaded.Chat.controllers
{
    class LoginController
    {
        public static void CharacterExecute(ChatSession chatSession)
        {
            CreateController(chatSession);
        }

        public static void ModExecute(ChatSession chatSession)
        {
            var client = chatSession.Client;
            var mod = (Moderator) chatSession.Character;

            mod.Online = true;

            client.Send(Constants.CMD_ADMIN_LOGIN_OK + "%" + mod.Id + "@" + DateTime.Now.ToShortTimeString() + "#");

            SendAdminRoomList(chatSession);
            SendAdminItemList(chatSession);

            CreateController(chatSession);
            //mod.Controller.Login();
        }

        public static void SendAdminRoomList(ChatSession chatSession)
        {
            var roomStr = "";
            foreach (var room in Chat.StorageManager.Rooms.Values)
            {
                roomStr += room.Id + "|" + room.RoomnameId + "|" + room.Game.Id + "|" + room.Instance.Id + "|" +
                           room.Language.Id + "|" + room.CompanyId + "|" + room.TabOrder + "|" + (int)(room.RoomType) + "|" +
                           Convert.ToInt32(room.NewComerRoom) + "|" + Convert.ToInt32(room.MultilanguageRoom) + "|" +
                           room.SectorId + "|" +
                           room.ParentId + "|" + room.MaxUsersPerChild + "|" + room.MaxAvgRoomUsers + "}";

            }

            chatSession.Client.Send(Constants.CMD_SET_ADMIN_ROOMLIST + "%" + roomStr + "@#");
        }

        public static void SendAdminItemList(ChatSession gameSession)
        {
            gameSession.Client.Send("g%" +
            "" + GetGameItems() + "@" +
            "" + GetInstances() + "@" +
            "" + GetLanguages() + "@" +
            "" + GetBadWords() + "@" +
            "" + GetAdminLevels() + "@" +
            "" + GetModsInfo() + "@" +
            "" + GetProjects() + "@" +
            "" + GetWordFilter() + "@" +
            "" + GetVersion() + "@" +
            "" + GetTextModules() + "" +
            "#");

        }

        private static void CreateController(ChatSession gameSession)
        {
            var character = gameSession.Character;

            character.Controller = null;

            if (character is Moderator && character.Controller == null) 
                gameSession.Character.Controller = new ModController(gameSession.Character);
            else if (character.Controller == null)
                gameSession.Character.Controller = new PlayerController(gameSession.Character);     
        }

        private static string GetGameItems()
        {
            string baseStr = "";
            foreach (var game in Chat.StorageManager.Games.Values)
            {
                if (baseStr == "")
                    baseStr += game.Id + "|" + game.Longname + "|" + game.Shortname + "|" + game.CreatorId;
                else baseStr += "}" + game.Id + "|" + game.Longname + "|" + game.Shortname + "|" + game.CreatorId;
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetInstances()
        {
            string baseStr = "";
            foreach (var instance in Chat.StorageManager.Instances.Values)
            {
                if (baseStr == "")
                    baseStr += instance.Id + "|" + instance.Longname + "|" + instance.Shortname + "|" + instance.CreatorId;
                else baseStr += "}" + instance.Id + "|" + instance.Longname + "|" + instance.Shortname + "|" + instance.CreatorId;
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetLanguages()
        {
            string baseStr = "";
            foreach (var language in Chat.StorageManager.Languages.Values)
            {
                if (baseStr == "")
                    baseStr += language.Id + "|" + language.Longname + "|" + language.Shortname + "|" + language.CreatorId;
                else baseStr += "}" + language.Id + "|" + language.Longname + "|" + language.Shortname + "|" + language.CreatorId;
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetBadWords()
        {
            string baseStr = "";
            foreach (var badWord in Chat.StorageManager.BadWords.Values)
            {
                if (baseStr == "")
                    baseStr += badWord.Id + "|" + badWord.Word + "|" + badWord.Level + "|" + badWord.Language.Id + "|" + badWord.CreatorId + "|" + string.Join(",", badWord.GameIDs);
                else baseStr += "}" + badWord.Id + "|" + badWord.Word + "|" + badWord.Level + "|" + badWord.Language.Id + "|" + badWord.CreatorId + "|" + string.Join(",", badWord.GameIDs);
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetAdminLevels()
        {
            string baseStr = "";
            foreach (var adminLevel in Chat.StorageManager.ModeratorLevels.Values)
            {
                if (baseStr == "")
                    baseStr += adminLevel.Id + "|" + (int) adminLevel.Level + "|" + adminLevel.Label + "|" +
                               Convert.ToInt32(adminLevel.DeBan) + "|" +
                               +Convert.ToInt32(adminLevel.ShowIp) + "|" + Convert.ToInt32(adminLevel.EnterSupportTab) +
                               "|" + Convert.ToInt32(adminLevel.EnterRoomsTab) + "|" +
                               +Convert.ToInt32(adminLevel.EnterWordFilterTab) + "|" +
                               Convert.ToInt32(adminLevel.EnterAccountsTab) + "|" +
                               Convert.ToInt32(adminLevel.CreateGame) + "|" +
                               +Convert.ToInt32(adminLevel.UpdateGame) + "|" + Convert.ToInt32(adminLevel.DeleteGame) +
                               "|" + Convert.ToInt32(adminLevel.CreateInstance) + "|" +
                               +Convert.ToInt32(adminLevel.UpdateInstance) + "|" +
                               Convert.ToInt32(adminLevel.DeleteInstance) + "|" +
                               Convert.ToInt32(adminLevel.CreateLanguage) + "|" +
                               +Convert.ToInt32(adminLevel.UpdateLanguage) + "|" +
                               Convert.ToInt32(adminLevel.DeleteLanguage) + "|" + Convert.ToInt32(adminLevel.CreateRoom) +
                               "|" + Convert.ToInt32(adminLevel.UpdateRoom) + "|" +
                               +Convert.ToInt32(adminLevel.DeleteRoom) + "|" + Convert.ToInt32(adminLevel.CreateBadWord) +
                               "|" + Convert.ToInt32(adminLevel.UpdateBadWord) + "|" +
                               Convert.ToInt32(adminLevel.DeleteBadWord) + "|" +
                               +Convert.ToInt32(adminLevel.IpBan) + "|" + Convert.ToInt32(adminLevel.IpDeban) + "|" +
                               Convert.ToInt32(adminLevel.ReadChatLoggingHistory) + "|" +
                               Convert.ToInt32(adminLevel.ReadPersonalAdminInfo) + "";
                else
                    baseStr += "}" + adminLevel.Id + "|" + (int) adminLevel.Level + "|" + adminLevel.Label + "|" +
                               Convert.ToInt32(adminLevel.DeBan) + "|" +
                               +Convert.ToInt32(adminLevel.ShowIp) + "|" + Convert.ToInt32(adminLevel.EnterSupportTab) +
                               "|" + Convert.ToInt32(adminLevel.EnterRoomsTab) + "|" +
                               +Convert.ToInt32(adminLevel.EnterWordFilterTab) + "|" +
                               Convert.ToInt32(adminLevel.EnterAccountsTab) + "|" +
                               Convert.ToInt32(adminLevel.CreateGame) + "|" +
                               +Convert.ToInt32(adminLevel.UpdateGame) + "|" + Convert.ToInt32(adminLevel.DeleteGame) +
                               "|" + Convert.ToInt32(adminLevel.CreateInstance) + "|" +
                               +Convert.ToInt32(adminLevel.UpdateInstance) + "|" +
                               Convert.ToInt32(adminLevel.DeleteInstance) + "|" +
                               Convert.ToInt32(adminLevel.CreateLanguage) + "|" +
                               +Convert.ToInt32(adminLevel.UpdateLanguage) + "|" +
                               Convert.ToInt32(adminLevel.DeleteLanguage) + "|" + Convert.ToInt32(adminLevel.CreateRoom) +
                               "|" + Convert.ToInt32(adminLevel.UpdateRoom) + "|" +
                               +Convert.ToInt32(adminLevel.DeleteRoom) + "|" + Convert.ToInt32(adminLevel.CreateBadWord) +
                               "|" + Convert.ToInt32(adminLevel.UpdateBadWord) + "|" +
                               Convert.ToInt32(adminLevel.DeleteBadWord) + "|" +
                               +Convert.ToInt32(adminLevel.IpBan) + "|" + Convert.ToInt32(adminLevel.IpDeban) + "|" +
                               Convert.ToInt32(adminLevel.ReadChatLoggingHistory) + "|" +
                               Convert.ToInt32(adminLevel.ReadPersonalAdminInfo) + "";
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetModsInfo()
        {
            string baseStr = "";
            foreach (var moderator in Chat.StorageManager.Moderators.Values)
            {
                if (baseStr == "")
                    baseStr += moderator.Id + "|" + moderator.Name + "|" + moderator.Hierarchy.Id + "|" +
                               moderator.CreatorId + "|" + moderator.GetAssignedRooms() + "|" +
                               moderator.GetFavoriteRooms() + "|" + moderator.ChatColor + "|" + moderator.LastLogin +
                               "|" + moderator.LastLogin + "|" + Convert.ToInt32(moderator.Online) + "|0|" +
                               Convert.ToInt32(moderator.Invisible) + "|" + moderator.Forename + "|" +
                               moderator.Lastname + "|" + moderator.Birthday + "";
                else
                    baseStr += "}" + moderator.Id + "|" + moderator.Name + "|" + moderator.Hierarchy.Id + "|" +
                               moderator.CreatorId + "|" + moderator.GetAssignedRooms() + "|" +
                               moderator.GetFavoriteRooms() + "|" + moderator.ChatColor + "|" + moderator.LastLogin +
                               "|" + moderator.LastLogin + "|" + Convert.ToInt32(moderator.Online) + "|0|" +
                               Convert.ToInt32(moderator.Invisible) + "|" + moderator.Forename + "|" +
                               moderator.Lastname + "|" + moderator.Birthday + "";
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetProjects()
        {
            string baseStr = "";
            foreach (var project in Chat.StorageManager.Projects.Values)
            {
                if (baseStr == "")
                    baseStr += project.Id + "|" + project.Game.Id + "|" + project.Instance.Id + "";
                else baseStr += "}" + project.Id + "|" + project.Game.Id + "|" + project.Instance.Id + "";
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }

        private static string GetWordFilter()
        {
            return "test|test2";
        }

        private static string GetVersion()
        {
            return "2.3.18";
        }

        private static string GetTextModules()
        {
            var baseStr = "";
            foreach (var textModule in Chat.StorageManager.TextModules.Values)
            {
                if (baseStr == "")
                    baseStr += textModule.Id + "|" + textModule.Description + "|" + textModule.Text;
                else baseStr += "}" + textModule.Id + "|" + textModule.Description + "|" + textModule.Text;
            }
            if (baseStr == "") baseStr = "-1";
            return baseStr;
        }
    }
}
