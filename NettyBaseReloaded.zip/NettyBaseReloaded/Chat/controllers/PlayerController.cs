﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.objects.chat;

namespace NettyBaseReloaded.Chat.controllers
{
    class PlayerController : AbstractCharacterController
    {
        public PlayerController(Character character) : base(character)
        {
            
        }

        public void Tick()
        {
            
        }
    }
}
