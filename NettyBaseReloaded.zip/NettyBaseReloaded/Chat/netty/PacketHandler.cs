﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.netty.handlers;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Chat.netty
{
    class PacketHandler
    {
        public static Dictionary<string, IHandler> HandledPackets = new Dictionary<string, IHandler>();

        public static void AddPackets()
        {
            HandledPackets.Add(Constants.CMD_GET_ADMIN_ROOMLIST, new SetAdminRoomlistHandler());
            HandledPackets.Add(Constants.CMD_GET_ITEMLIST, new SetAdminItemListHandler());
        }

        public static void Handle(ChatClient client, string packet)
        {
            var newpacket = packet.Replace('@', '%');
            var splitted = newpacket.Split('%');
            if (splitted[0] == Constants.CMD_ADMIN_LOGIN)
                new AdminLoginHandler().execute(client, splitted);
            else
                if (HandledPackets.ContainsKey(splitted[0])) HandledPackets[splitted[0]].execute(Chat.StorageManager.GetChatSession(client.UserId), splitted);

            Console.WriteLine(packet);
        }
    }
}
