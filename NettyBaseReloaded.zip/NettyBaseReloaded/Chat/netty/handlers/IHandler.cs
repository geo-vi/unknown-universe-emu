﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.objects;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Chat.netty.handlers
{
    interface IHandler
    {
        void execute(ChatSession client, string[] param);
    }
}
