﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.controllers;
using NettyBaseReloaded.Chat.objects;

namespace NettyBaseReloaded.Chat.netty.handlers
{
    class SetAdminRoomlistHandler : IHandler
    {
        public void execute(ChatSession chatSession, string[] param)
        {
            if (chatSession == null) return;

            LoginController.SendAdminRoomList(chatSession);
        }
    }
}
