﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NettyBaseReloaded.Chat.controllers;
using NettyBaseReloaded.Chat.objects;
using NettyBaseReloaded.Chat.objects.chat;
using NettyBaseReloaded.Game.objects.world.players;
using NettyBaseReloaded.Networking;

namespace NettyBaseReloaded.Chat.netty.handlers
{
    class AdminLoginHandler
    {
        public void execute(ChatClient client, string[] param)
        {
            var username = param[2];
            var password = param[3];
            var invisible = Convert.ToBoolean(int.Parse(param[4]));

            var data = DataCheck(username, password);

            if (data == null)
            {
                client.Send(Constants.CMD_ADMIN_NOT_EXIST + "#");
                return;
            }

            data.Invisible = invisible;

            client.UserId = data.Id;

            var chatSession = new ChatSession(data)
            {
                Client = client
            };

            if (!Chat.StorageManager.ChatSessions.ContainsKey(data.Id))
                Chat.StorageManager.ChatSessions.Add(data.Id, chatSession);
            else
                Chat.StorageManager.ChatSessions[data.Id] = chatSession;

            LoginController.ModExecute(chatSession);
        }

        private Moderator DataCheck(string username, string password)
        {
            if (username == "Shock" && password == "test")
            {
                return Chat.StorageManager.Moderators[0];
            }
            return null;
        }
    }
}
