﻿using System.Collections.Generic;
using NettyBaseReloaded.Chat.controllers;
using NettyBaseReloaded.Game.objects.world.players;

namespace NettyBaseReloaded.Chat.objects.chat
{
    class Character
    {
        /// <summary>
     /// Chat client's ID
     /// </summary>

        public int Id { get; set; }

        /// <summary>
        /// Chat client's name
        /// </summary>

        public string Name { get; set; }

        /// <summary>
        /// Chat client's running language (Currently supported: 'en')
        /// </summary>

        public string Language { get; set; }

        public Dictionary<int, Room> ConnectedRooms { get; set; }

        public Clan Clan { get; set; }

        public bool Rcon { get; set; }

        public AbstractCharacterController Controller { get; set; }

        public Character(int id, string name, Clan clan, Dictionary<int, Room> connectedRooms, string lang)
        {
            Id = id;
            Name = name;
            Language = lang;
            Clan = clan;
            ConnectedRooms = connectedRooms;
        }

        public bool IsRcon()
        {
            return Rcon;
        }
    }
}
