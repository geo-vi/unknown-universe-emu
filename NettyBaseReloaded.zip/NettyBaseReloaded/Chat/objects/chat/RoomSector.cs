﻿namespace NettyBaseReloaded.Chat.objects.chat
{
    class RoomSector
    {
        public int RoomnameId { get; set; }

        public RoomSector(int roomnameId)
        {
            RoomnameId = roomnameId;
        }
    }
}
